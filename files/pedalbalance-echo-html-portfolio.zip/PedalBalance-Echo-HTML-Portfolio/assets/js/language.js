const SUPPORTED_LANGUAGES = new Set(['zh', 'en', 'ja']);

export function setLanguage(language) {
  const lang = SUPPORTED_LANGUAGES.has(language) ? language : 'zh';
  document.documentElement.lang = lang === 'zh' ? 'zh-CN' : lang;
  document.querySelectorAll('[data-lang]').forEach((node) => {
    node.hidden = node.dataset.lang !== lang;
  });
  document.querySelectorAll('[data-language]').forEach((button) => {
    const active = button.dataset.language === lang;
    button.setAttribute('aria-pressed', String(active));
  });
  try {
    localStorage.setItem('pedalbalance-language', lang);
  } catch {
    // The page remains usable when local storage is disabled.
  }
  document.dispatchEvent(new CustomEvent('pedalbalance:language', { detail: { language: lang } }));
  return lang;
}

export function mountLanguageControls() {
  let saved = 'zh';
  try {
    saved = localStorage.getItem('pedalbalance-language') || 'zh';
  } catch {
    saved = 'zh';
  }
  setLanguage(saved);
  document.querySelectorAll('[data-language]').forEach((button) => {
    button.addEventListener('click', () => setLanguage(button.dataset.language));
  });
}
