# PedalBalance Echo — 本地审阅包

这是一个三页、三语、无构建步骤的作品集网站原型。它把项目定义为自行车上的“人 → 机器 → 人”学习回路：左右踏板的相对压力代理进入机器，机器按完整曲柄一圈判断持续偏差，再把短促振动提示送回需要注意的一侧脚踝。使用者主动调整动作，装置不替人动作。

## 最快打开方法

不要直接双击 `file://`：页面使用原生 ES modules，浏览器会限制本地模块加载。请在这个文件夹打开终端并运行：

```bash
python3 -m http.server 9876
```

然后访问：

- `http://localhost:9876/index.html`
- `http://localhost:9876/prototype-making.html`
- `http://localhost:9876/experiment-capabilities.html`

若 9876 端口被占用，可换成任意未占用端口。

## 三页结构

1. `index.html` — 项目愿景：第一屏动画直接画出人、自行车、腿部肌肉、踏板输入、机器判断和脚踝反馈；随后解释完整一圈、C1、E2、研究关系和边界。
2. `prototype-making.html` — 制作：三节点系统、零件照片、安装图、数据管线、可复用代码、教学视频、14天日程和预算。
3. `experiment-capabilities.html` — 实验与能力：校准、C1条件、E2轨迹、指标、故障处理、安全、伦理以及12项能力证据。

每页右上角可切换中文、英文和日文。“Open Interactive Prototype”会打开九幕全屏演示；九幕分别采用闭环、模块、三帧因果、变量矩阵、系统数字、任务条件、轨迹来源、实验时间线和学习证据对照；STOP OUTPUT在每一幕都可用。

## 文件结构

```text
assets/css/                 视觉系统、响应式布局、原型覆盖层
assets/js/                  动画、状态机、三语切换、实验模拟
assets/images/components/   零件参考图
assets/images/tutorials/    教学视频参考缩略图
data/components.json        零件角色、限制、文档和教程映射
data/sources.json           可审计来源与媒体使用状态
tests/                      内容契约、模型和整站验证
SOURCES.md                  发布前的来源与版权操作
VALIDATION.md               本次检查记录
```

## 发布前必须替换的图片

当前六张 manufacturer product image 只用于本地评审和采购识别，页面已有清晰署名；没有把它们当作个人制作证据。公开发布前，必须用自己购买、焊接、固定和测试后的原创照片替换，并保留产品链接用于说明选型来源。YouTube缩略图也只作为带链接的内部学习参考；公开版本最好换成原创教程笔记截图或获得许可的媒体。

## 明确边界

- 原型只用于固定式室内脚踏器，不用于道路骑行。
- 不提供、不制作、不操作DIY EMS/TENS/FES。身体输出为可随时停止的低强度振动提示。
- 可选EMG只作为读取肌肉活动变化的传感输入，不向身体送电。
- 两个FSR只形成“完整一圈内左右相对压力贡献”的低成本代理，不代表功率、扭矩、肌力、临床诊断或骑行正确性。
- 页面中的图表和全屏演示标为 `ILLUSTRATIVE SIMULATION`；研究方案标为 `PLANNED STUDY`。真实制作和采集完成前不得改写为结果。

## 合并到作品集网站

保留三份HTML、`assets/`与`data/`的相对目录关系即可迁移。若作品集已有全局导航，可抽取每页的 `<main>` 内容，但同时需要迁移 `site.css`、全部JavaScript模块和本地图片。所有行为均为原生HTML/CSS/JavaScript，不依赖框架或第三方CDN。

## 自动检查

在项目文件夹的上一级运行：

```bash
node --test PedalBalance-Echo-HTML-Portfolio/tests/*.test.mjs
```

若系统没有Node，可只进行浏览器检查；但迁移或替换图片后建议再次跑完整测试。
