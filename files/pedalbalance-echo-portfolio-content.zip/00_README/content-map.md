# Content Map：三页内容编号总表

本文件定义三种语言必须共同拥有的内容块。标题可以自然翻译，但 ID 不得改变。

## Page 1 — Project Vision

| Content ID | 功能 | 必须包含 |
|---|---|---|
| P1-META-01 | 页面 SEO/摘要 | 项目名、研究型原型、三类输入/输出 |
| P1-HERO-01 | 首屏标签 | Embodied Interaction / Research Prototype |
| P1-HERO-02 | 主标题 | 身体动作被机器读取、解释并返回身体 |
| P1-HERO-03 | 首屏摘要 | 自行车左右腿、相对压力、触觉、past-self |
| P1-HERO-04 | 关键事实条 | 14 days / 3 nodes / 2 questions / no DIY EMS |
| P1-PROBLEM-01 | 问题背景 | 屏幕反馈与身体动作之间的注意转换 |
| P1-PROBLEM-02 | 自行车场景 | 左右交替、瞬时比较为何错误 |
| P1-INSIGHT-01 | 核心洞察 | 位置与信息语义一致的身体反馈 |
| P1-LOOP-01 | 系统闭环 | Human → Machine → Human → Learning |
| P1-SCENARIO-01 | 使用情境 | 基线、持续偏差、振动、主动修正 |
| P1-RESEARCH-01 | C1 问题 | 反馈何时退出才留下独立技能 |
| P1-RESEARCH-02 | E2 问题 | 过去自己的身体数据能否回到现在 |
| P1-RELATED-01 | 研究启发 | Adaptive EMS、MyoAction、bioSync |
| P1-DESIGN-01 | 设计原则 | 身体对应、个体基线、撤除反馈、可追溯 |
| P1-SCOPE-01 | 安全转译 | EMS 机制问题转为振动/EMG 低风险平台 |
| P1-CONTRIBUTION-01 | 项目价值 | 能力证明而非创新声称 |
| P1-NEXT-01 | 下一页引导 | 从概念进入材料与制作 |

## Page 2 — Prototype & Making

| Content ID | 功能 | 必须包含 |
|---|---|---|
| P2-META-01 | 页面摘要 | 材料、三节点、开源复用、14 天 |
| P2-HERO-01 | 主标题 | 把研究问题做成可调试装置 |
| P2-ARCH-01 | 总架构 | 左脚、右脚、中央节点、浏览器 |
| P2-ARCH-02 | 左脚节点 | FSR、DRV2605L、振动、可选 EMG |
| P2-ARCH-03 | 右脚节点 | FSR、DRV2605L、振动 |
| P2-ARCH-04 | 中央节点 | Hall、舵机、USB、周期计算 |
| P2-HW-01 | XIAO ESP32-C3 | 角色、关键规格、图位、来源 |
| P2-HW-02 | Interlink 402 FSR | 相对测量、安装限制、来源 |
| P2-HW-03 | DRV2605L | I2C、触感波形、库 |
| P2-HW-04 | 振动电机 | 左右踝部定位、备用件 |
| P2-HW-05 | Hall + magnet | 每圈事件、非接触安装 |
| P2-HW-06 | 9g servo | 物理平衡指针、独立电源 |
| P2-HW-07 | SEN0240 EMG | 只读、可选、干电极、规格 |
| P2-HW-08 | LiPo + power | 电池、USB、锂电边界 |
| P2-HW-09 | Pedal exerciser | 固定室内平台 |
| P2-HW-10 | Tools/consumables | 焊接、万用表、泡棉、端子、热缩 |
| P2-COST-01 | 预算 | 日期标记、最小/完整预算 |
| P2-MOUNT-01 | FSR 安装 | 扩散片、EVA、防剪切、可拆卸 |
| P2-MOUNT-02 | 触觉安装 | 左右踝外侧、定位测试 |
| P2-MOUNT-03 | EMG/肌肉图 | vastus lateralis 作为说明性单点、局限 |
| P2-MOUNT-04 | Hall/机械 | 磁铁双保险、远离运动路径 |
| P2-DATA-01 | 数据流 | 采样、ESP-NOW、周期、USB、输出 |
| P2-ALGO-01 | 周期计算 | left_area/right_area/left_share |
| P2-REUSE-01 | Smart Chair | FSR、EMA、校准、CSV、MIT |
| P2-REUSE-02 | ESP-NOW | 官方多节点示例 |
| P2-REUSE-03 | FTMS server | Hall、tachMount、MIT |
| P2-REUSE-04 | Adafruit library | DRV2605L 库、MIT |
| P2-REUSE-05 | Insole project | 多点压力升级、CC BY-NC |
| P2-REUSE-06 | DFRobot examples | EMG 接线、波形和 demo |
| P2-BUILD-01 | 14 天总计划 | 每阶段可展示成果 |
| P2-BUILD-02 | D1–D4 | 传感器、双侧、无线 |
| P2-BUILD-03 | D5–D9 | Hall、算法、触觉、舵机、串口 |
| P2-BUILD-04 | D10–D14 | EMG、CAD、实验、演示 |
| P2-GATE-01 | 调试门槛 | 单模块优先、失联测试、左右定位 |
| P2-DONTBUY-01 | 不购买 | EMS、功率踏板、3D 打印机、PCB |
| P2-NEXT-01 | 下一页引导 | 从制作进入实验与证据 |

## Page 3 — Experiment & Capabilities

| Content ID | 功能 | 必须包含 |
|---|---|---|
| P3-META-01 | 页面摘要 | C1、E2、数据、能力、安全 |
| P3-HERO-01 | 主标题 | 把原型变成可证伪的研究演示 |
| P3-FRAME-01 | 共同母问题 | 指导来自谁、何时撤除 |
| P3-CAL-01 | 校准 | 零载、同重量、60 秒个人基线 |
| P3-SESSION-01 | 会话流程 | 安全、校准、训练、撤除、导出 |
| P3-C1-01 | C1 条件 | Visual/Continuous/Fixed/Adaptive |
| P3-C1-02 | C1 结果 | 无辅助后测、24h 保持、迁移 |
| P3-E2-01 | E2 轨迹 | 保存最佳过去自己轨迹 |
| P3-E2-02 | E2 条件 | PS-H/MO-H/PS-V/NF |
| P3-E2-03 | E2 诚实标记 | simulated matched-other |
| P3-RULE-01 | 反馈规则 | 连续三圈、弱中强、恢复停止 |
| P3-METRIC-01 | 主要指标 | 无反馈偏差、迁移、跟随误差 |
| P3-METRIC-02 | 工程指标 | 丢包、延迟、有效圈、定位准确率 |
| P3-DATA-01 | 数据字典 | 完整字段列表 |
| P3-ANALYSIS-01 | 分析 | 不夸大单人数据、图表建议 |
| P3-FAIL-01 | 故障 | 500 ms 失联、无 Hall、低压力、EMG 缺失 |
| P3-SAFETY-01 | 人体安全 | 固定设备、只读 EMG、停止条件 |
| P3-ETHICS-01 | 伦理 | 自测与招募参与者边界 |
| P3-LIMIT-01 | 局限 | FSR、单肌肉 EMG、模拟他人、样本 |
| P3-SKILL-01 | 技能证据 | 硬件、代码、CAD、IoT、实验、研究复现 |
| P3-EVIDENCE-01 | 成果证据链 | 照片、日志、CAD、CSV、视频、失败记录 |
| P3-PROTOTYPE-01 | 交互原型入口 | 模拟/硬件模式、状态机、导出 |
| P3-DEMO-01 | 90 秒演示 | 输入、计算、输出、撤除、过去自己 |
| P3-REFLECT-01 | 反思 | 组合能力比“从零发明”更重要 |
| P3-NEXT-01 | 后续研究 | 导师监督下的 EMS/更高质量测量 |

## 共用图像 ID

| Image ID | 主题 | 建议出现页 |
|---|---|---|
| IMG-01 | Hero：人体—自行车—机器闭环 | Page 1 |
| IMG-02 | Human → Machine → Human 系统图 | Page 1 |
| IMG-03 | 四阶段使用情境 | Page 1 |
| IMG-04 | C1/E2 研究空间二维图 | Page 1 |
| IMG-05 | 全部零件俯拍 | Page 2 |
| IMG-06 | 三节点架构图 | Page 2 |
| IMG-07 | 踏板 FSR 剖面与安装 | Page 2 |
| IMG-08 | 自行车身体与传感器标注图 | Page 2 |
| IMG-09 | vastus lateralis 与只读 EMG 说明图 | Page 2 |
| IMG-10 | Hall、磁铁与舵机机械安装 | Page 2 |
| IMG-11 | 开源复用拼装图 | Page 2 |
| IMG-12 | 14 天制作时间线 | Page 2 |
| IMG-13 | 校准—训练—撤除—迁移流程 | Page 3 |
| IMG-14 | C1 四条件矩阵 | Page 3 |
| IMG-15 | E2 四条件矩阵 | Page 3 |
| IMG-16 | 实时原型仪表板线框图 | Page 3 |
| IMG-17 | 数据字段与故障状态 | Page 3 |
| IMG-18 | 技能证据链 | Page 3 |

