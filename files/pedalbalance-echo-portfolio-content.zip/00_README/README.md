# PedalBalance Echo 三语作品集纯文本材料包

版本：2026-08-16  
项目：PedalBalance Echo — Human → Machine → Human Cycling Interface  
交付形式：纯文本 Markdown  
语言：中文、English、日本語

## 1. 这个文件夹是什么

这是一个供作品集建站工具使用的“内容源”，不是已经排好的网站。它把 PedalBalance Echo 项目拆成三页案例研究，并为每一页分别提供中文、英文和日文完整文案。

材料包同时包含：

- 页面上会出现的标题、副标题、正文、卡片、图注、警告和按钮文字；
- 每一张建议图片、示意图、接线图和结果图的文字简报；
- 图中应该标注哪些部位、线条应指向哪里、图注怎样写；
- 独立交互原型应该有哪些状态和屏幕；
- 产品、论文、代码库和教程的来源链接；
- 开源代码哪些可以改、哪些只能参考、怎样署名；
- 三种语言共用的内容 ID、图像 ID 和术语表。

本包**不包含**：

- HTML、CSS 或 JavaScript；
- 已下载的商品图片、论文截图或厂商素材；
- AI 生成图或人体解剖图；
- 可直接运行的硬件固件；
- EMS/TENS/FES 人体刺激参数或制作教程。

## 2. 建站时先读哪些文件

建议后续 Codex 按以下顺序读取：

1. 本文件；
2. [content-map.md](./content-map.md)；
3. 选择一个语言目录中的三页主文案；
4. 读取 `04_Website-Production-Notes/page-layout-and-interactions.md`；
5. 需要配图时读取 `image-and-diagram-briefs.md`；
6. 制作交互演示时读取 `prototype-demo-script.md`；
7. 发布前读取 `open-source-and-citations.md` 和 `captions-alt-text-labels.md`。

## 3. 三页结构

### Page 1 — Project Vision

介绍问题、概念、Human → Machine → Human 闭环、自行车身体场景、C1/E2 研究问题、安全转译和项目价值。

### Page 2 — Prototype & Making

介绍材料、零件、节点、电路、安装、数据流、开源复用、制作计划、调试方法、预算和过程能力。

### Page 3 — Experiment & Capabilities

介绍校准、实验条件、反馈撤除、保持、迁移、过去自我轨迹重放、数据分析、风险、局限和能力证据。

## 4. 三种语言怎样对应

三种语言不是逐句排在同一文件，而是三个可以独立发布的版本：

```text
01_Chinese/page-1-project-vision.md
02_English/page-1-project-vision.md
03_Japanese/page-1-project-vision.md
```

每个内容块前都有相同 ID，例如：

```text
[CONTENT ID: P1-LOOP-01]
```

建站工具可以用 ID 对齐三个版本，而不用根据标题猜测对应关系。产品型号、研究条件缩写、数据字段和图像 ID 在三种语言中保持一致。

## 5. 文档标记说明

| 标记 | 含义 | 是否显示在最终网站 |
|---|---|---|
| `[CONTENT ID: …]` | 三语映射键 | 否 |
| `[LAYOUT]` | 建议页面构图 | 否 |
| `[IMAGE XX]` | 图片位置和画面要求 | 否 |
| `[ANNOTATION]` | 图中线标和编号 | 只显示标注文字 |
| `[CAPTION]` | 图片下方的公开图注 | 是 |
| `[ALT]` | 图片无障碍替代文字 | HTML 属性，不直接显示 |
| `[INTERACTION]` | 建议交互 | 否 |
| `[PROTOTYPE]` | 独立原型入口或状态 | 部分显示 |
| `[SOURCE]` | 事实或素材来源 | 视页面设计决定 |
| `[PORTFOLIO NOTE]` | 给建站者的说明 | 否 |

## 6. 发布前的图片规则

本包提供产品页、厂商文档和论文的链接，是为了让设计者确认零件外观与技术事实，并不表示这些图片已经取得作品集转载许可。

建议优先级：

1. 购买后自己拍摄的产品、面包板、电路、焊接和安装照片；
2. 自己绘制的系统图、接线图、人体轮廓图和数据图；
3. 厂商明确提供的媒体资源，并按照其授权方式署名；
4. 商品页截图只用于过程记录或内部选图，不默认公开发布。

论文图表也不能因为论文可访问就自动视为可自由转载。发布前检查论文许可证；可以用自己的结构重画概念图，并在图注中写“adapted from”及完整来源。

## 7. 项目的安全边界

PedalBalance Echo 是固定室内脚踏原型，不是道路骑行设备、医疗器械或自行车功率计。

- 左右 FSR 只产生“完整踏圈内的相对压力贡献代理指标”；
- 身体输出使用左右踝部振动，不向人体输出电流；
- SEN0240 只读取表面肌电，是可选验证模块；
- EMG 不控制提示，也不用于诊断疲劳、伤病或肌肉强弱；
- 招募他人测试前，需要与导师确认伦理审批、监督和安全流程；
- 作品集不得写成已经证明训练有效，除非未来完成了相应研究。

## 8. 当前完成状态怎样表述

如果硬件尚未全部完成，使用以下公开状态：

> This case study documents a research-through-making plan and an interactive system prototype. Hardware validation and human-subject evaluation are presented as planned or in-progress work unless accompanied by recorded build evidence and data.

中文：

> 本案例记录一个 research-through-making 研究计划与交互系统原型。除非附有实际制作证据和数据，硬件验证与人体实验均明确写为计划中或进行中，而不写成已经完成。

日文：

> 本ケーススタディは、Research through Making の計画とインタラクション・プロトタイプをまとめたものである。実機の記録やデータがない段階では、ハードウェア検証と人を対象とする評価を「計画中」または「進行中」と明示する。

## 9. 后续建站工具的最小任务

- 使用三页结构，不再拆成 6–8 个碎片页面；
- 每页保留一个明确的主问题；
- 作品集正文与制作说明分离；
- Prototype 作为单独入口，但从三页都可以访问；
- 保留来源、局限和安全信息，不把它们藏到无法发现的位置；
- 不自动抓取或热链商品图片；
- 不删除内容 ID，直到三语网站测试完成；
- 移动端保持图注、编号和交互状态可读。

## 10. 推荐的最终页面导航文字

| ID | 中文 | English | 日本語 |
|---|---|---|---|
| NAV-01 | 项目概念 | Project Vision | プロジェクト構想 |
| NAV-02 | 原型与制作 | Prototype & Making | プロトタイプと制作 |
| NAV-03 | 实验与能力 | Experiment & Capabilities | 実験設計とスキル |
| NAV-04 | 打开交互原型 | Open Interactive Prototype | インタラクティブ・プロトタイプ |
| NAV-05 | 查看材料清单 | View Bill of Materials | 部品表を見る |
| NAV-06 | 查看研究方法 | View Study Design | 実験計画を見る |

