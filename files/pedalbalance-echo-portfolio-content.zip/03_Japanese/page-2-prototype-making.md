# Page 2｜Prototype & Making：プロトタイプと制作

[PORTFOLIO NOTE] 商品カタログではなく、「研究課題をどのようにデバッグ可能な装置へ変えたか」として構成する。購入先より先に、各部品の役割を説明する。

---

[CONTENT ID: P2-META-01]

**ページタイトル**  
Prototype & Making｜3枚の開発ボードから身体ループへ

**ページ概要**  
PedalBalance Echoは、3台のXIAO ESP32-C3、2枚のFSR、Hall回転センサー、左右触覚、物理ポインターで最小構成を作る。既存ライブラリ、公式チュートリアル、オープンソースを基盤として利用し、各モジュールを単体検証してから無線統合する。

---

[CONTENT ID: P2-HERO-01]

# 研究課題を、一つずつ失敗できる装置へ変える

2週間で完成させるため、モータードライバ、無線プロトコル、EMGフロントエンドをゼロから作らない。左足、右足、中央ハブへ機能を分け、既存のセンシング例、ESP-NOW、触覚ライブラリを使う。制作時間は、ペダリング固有の判断——1回転モデル、身体マッピング、ガイダンスの撤去、追跡可能なログ——へ集中させる。

**リード文**  
Build small. Test one signal at a time. Integrate only after every module can fail safely.

[IMAGE IMG-05] 中立背景の俯瞰写真。XIAO 3枚、FSR 2枚、DRV2605L 2枚、振動モーター3個、Hall、磁石、サーボ、EMG、電池2個、固定式ペダルを配置し、名称と数量だけを表示する。

[CAPTION] 圧力と回転を機械へ取り込み、触覚と物理状態を身体へ返す、低コストでモジュール化された身体インターフェース。

[ALT] PedalBalance Echoの主要部品を、入力、計算、出力、任意の検証モジュールに分けた写真。

---

[CONTENT ID: P2-ARCH-01]

## 三つのノード

```text
左圧力 + 任意EMG → 左足ノード ─┐
                                  ├─ ESP-NOW → 中央ハブ → USB → プロトタイプ/データ
右圧力            → 右足ノード ─┘                    ├─ Hall：1回転境界
                                                      └─ Servo：物理ポインター

中央ハブ → ESP-NOW → 左右ノード → 対応する足首の振動
```

この構成により、クランクを横切る配線を避けられる。足ノードは電池駆動、中央ハブはペダルフレームへ固定しUSBでPCへ接続する。左右にDRV2605Lを1枚ずつ置くため、同じ固定I2Cアドレスを一つのバスに重ねる問題もない。

[IMAGE IMG-06] sensing、computation、feedbackを色分けした三ノード図。各接続にAnalog ADC、ESP-NOW、I2C、USB Serial、PWMを表記する。

[CAPTION] モジュール境界を明確にすることで、圧力、無線、回転、触覚、画面を独立して検証できる。

[ALT] 左右足ノードが中央ハブへ無線接続し、ハブがHall、サーボ、PCへ接続する図。

[CONTENT ID: P2-ARCH-02]

### 左足ノード

- XIAO ESP32-C3；
- FSR 1枚と10 kΩ分圧；
- DRV2605L 1枚と10 mm振動モーター；
- 保護回路付き3.7 V LiPo；
- 任意のSEN0240 EMG；
- 50–100 Hzで圧力取得、25–50 Hzで送信；
- ハブからの指令が途絶えた場合は触覚を停止する。

[CONTENT ID: P2-ARCH-03]

### 右足ノード

- EMGを除き左足と同じ構成；
- 固有のノードID、パケット番号、電池；
- 左右で別コードを作らず、共通ファームウェアを`LEFT`/`RIGHT`設定で分ける。

[CONTENT ID: P2-ARCH-04]

### 中央ハブ

- USBデータケーブルでPCへ接続するXIAO ESP32-C3；
- 非ラッチ型Hallセンサーとクランク磁石；
- 9 gサーボと紙/3Dプリントのバランスダイヤル；
- 受信、欠損率、1回転分割、指標計算、提示送信、シリアルログ；
- サーボは独立5 V電源を使用し、ハブとGNDを共有する。GPIOから給電しない。

---

[CONTENT ID: P2-HW-01]

## 01｜XIAO ESP32-C3：三ノード共通の計算コア

21 × 17.8 mmの基板にESP32-C3、Wi‑Fi、BLE、USB-C、I2C、PWM、ADC、リチウム電池管理を備える。公式資料ではADC入力は4系統だが、本プロトタイプはA0/A1/A2のADC1を優先し、メーカーが誤サンプリングの可能性を示すA3/ADC2を避ける。

**数量**：3枚、任意で予備1枚。  
**役割**：左右足ノードと中央ハブ。  
**統一する利点**：ボード設定、書き込み手順、予備部品を共通化できる。

[IMAGE] 公式の表裏写真は選定参考とし、公開時は購入後の自分の写真へ置き換える。硬貨または定規でスケールを示す。

[SOURCE]

- [Seeed Studio XIAO ESP32-C3 公式ガイド](https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/)
- [豪州購入参考：Core Electronics](https://core-electronics.com.au/seeed-studio-xiao-esp32c3-tiny-mcu-board-with-wi-fi-and-ble-battery-charge-supported-power-efficiency-and-rich-interface.html)

[CONTENT ID: P2-HW-02]

## 02｜Interlink 402 FSR：相対的な圧力変化を観察する

FSRは荷重によって抵抗値が変化する薄膜センサーで、安価かつADCへ接続しやすい。一方、非線形性、ヒステリシス、個体差、装着方法の影響が大きく、パワーメーターにはならない。

各FSRを10 kΩと分圧し、同一重量を左右へ繰り返し載せる。raw、filtered、calibratedの値を残し、ワットへ直接変換しない。

**数量**：2枚、任意で予備1枚。  
**機械条件**：薄膜テールの横ずれを防ぎ、フィルム端子へ直接はんだ付けせず、ソケットまたは端子台を使う。

[SOURCE]

- [Little Bird：Interlink 402 FSR](https://littlebirdelectronics.com.au/products/round-force-sensitive-resistor-fsr-interlink-402)
- [Adafruit FSRガイド](https://learn.adafruit.com/force-sensitive-resistor-fsr)

[CONTENT ID: P2-HW-03]

## 03｜DRV2605L：触覚ドライバを再発明しない

DRV2605LはERM/LRA触覚モーター用I2Cドライバで、クリックやランプなどの波形を内蔵する。Adafruitの配線、例、Arduinoライブラリを使用し、左右に1枚ずつ配置する。弱・中・強の短い三パターンを選び、GPIOからモーターを直接駆動しない。

**数量**：2枚。  
**範囲**：区別しやすい短波形のみ。連続した高デューティ振動は行わない。

[SOURCE]

- [Adafruit DRV2605L公式ガイド](https://learn.adafruit.com/adafruit-drv2605-haptic-controller-breakout/overview)
- [Adafruit DRV2605 Arduino Library](https://github.com/adafruit/Adafruit_DRV2605_Library)
- [豪州購入参考](https://core-electronics.com.au/adafruit-drv2605l-haptic-motor-controller.html)

[CONTENT ID: P2-HW-04]

## 04｜10 mm振動モーター：左右の意味を足首へ返す

コイン型ERMモーターを左右足首外側の柔らかいストラップへ固定する。ペダル下へ置くと左右定位が曖昧になり、圧力信号へ機械振動が入りやすい。

**数量**：3個、左右各1個と予備1個。  
**対応**：左寄与低下→左提示、右寄与低下→右提示、回復→停止。  
**事前確認**：閉眼10回で8回以上正しく左右を識別する。

[SOURCE] [Little Bird：Mini Vibration Motor](https://littlebirdelectronics.com.au/products/mini-vibration-motor-10-2-7mm?collection=dfrobot)

[CONTENT ID: P2-HW-05]

## 05｜Hallセンサーと磁石：1回転ごとの境界

非ラッチ型Hallセンサーは磁石通過時にイベントを生成する。隣り合うイベント間を一つの`cycle_id`とし、時間差からケイデンスも求める。

**数量**：Hall 2個（1個は予備）、小型磁石1セット。  
**機械条件**：非接触、磁石の二重固定、クランク可動範囲に配線を置かない。

[SOURCE]

- [AH1815非ラッチ型Hallセンサー](https://core-electronics.com.au/hall-effect-sensor-ah1815-non-latching.html)
- [ESP32 stationary-bike Hall/FTMS例](https://github.com/jamesjmtaylor/esp32-ftms-server)

[CONTENT ID: P2-HW-06]

## 06｜9 gサーボ：機械の判断を物理状態にする

小型サーボで個人ベースラインを中心とするポインターを動かす。精密計測器ではなく、計算結果を物理世界へ表すtangible displayである。最初は紙のダイヤルを使い、寸法確定後に外装を作る。独立5 V電源、共通GND、ソフトウェア角度制限を用いる。

[SOURCE] [Jaycar 9 g Micro Servo](https://www.jaycar.com.au/arduino-compatible-9g-micro-servo-motor/p/YM2758)

[CONTENT ID: P2-HW-07]

## 07｜SEN0240：任意の読み取り専用sEMG

DFRobot/OYMotion SEN0240は、乾式電極、増幅、フィルタを組み合わせた表面筋電センサーである。出力は1.5 V付近を基準とする0–3.0 V、供給範囲は3.3–5.5 Vと記載されている。

目的は筋活動のタイミングを可視化し、身体入力の経路を示すこと。左右提示を制御せず、疲労、傷害、筋力、動作の正しさを診断しない。ケーブル運動、接触、クロストーク、振動アーチファクトを限界として記録する。

**数量**：1。  
**最初の利用**：安静と軽い静的収縮を比べた後、安全に固定できる場合のみ低速ペダリングを試す。

[SOURCE]

- [DFRobot SEN0240公式資料](https://wiki.dfrobot.com/sen0240/)
- [豪州購入参考](https://core-electronics.com.au/gravity-analog-emg-sensor-by-oymotion.html)

[CONTENT ID: P2-HW-08]

## 08｜LiPoと電源：クランク周辺からケーブルをなくす

左右ノードは保護回路付き3.7 V LiPoを使う。接続前に極性を確認し、身体から外して不燃性の場所で充電する。膨張、破損、異常発熱があれば使用を中止する。ハブはUSB、サーボは独立5 V / 2 Aで給電する。ベンチ段階ではUSBモバイルバッテリーを優先できる。

[SOURCE]

- [XIAO ESP32-C3 Battery Usage](https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/#battery-usage)
- [400 mAh protected LiPo参考](https://core-electronics.com.au/polymer-lithium-ion-battery-400mah-38456.html)

[CONTENT ID: P2-HW-09]

## 09｜固定式ペダル：制御された環境に限定する

ストラップと抵抗調整を備えた小型固定式ペダルで十分である。ロードバイク、高価なトレーナー、商用パワーメーターは不要。滑りにくい床、安定した座位、低抵抗・低速から開始する。

[SOURCE] [Everfit Mini Pedal Exerciser参考](https://www.kmart.com.au/product/everfit-pedal-exerciser-mini-exercise-bike-cross-trainer-under-desk-bike-black-110070790/)

[CONTENT ID: P2-HW-10]

## 10｜工具と消耗品：ブレッドボードから装着可能な形へ

はんだごて、マルチメーター、吸取器、ニッパー、ストリッパー、こて台、保護眼鏡、USB-Cデータケーブルを用意する。消耗品は小型ブレッドボード、10 kΩ/1 kΩ/220 Ω抵抗、100 nFコンデンサ、柔軟な配線、ソケット/端子、熱収縮チューブ、面ファスナー、EVA、荷重拡散板、結束バンド、M2/M3ねじである。

完成品だけでなく、導通確認、初期配線、はんだ、ストレインリリーフ、失敗、修正の写真を制作証拠として残す。

[SOURCE] [Jaycar soldering starter kit with multimeter](https://www.jaycar.com.au/25w-soldering-iron-starter-kit-with-dmm/p/TS1652)

---

[CONTENT ID: P2-COST-01]

## 予算はリアルタイム価格ではなく、範囲を管理する記録

2026年8月13日の計画時点では、XIAO 3枚、左右圧力/触覚、Hall、サーボ、EMG、工具、固定式ペダルの主要商品は約AUD 344.65。消耗品、送料、任意の3Dプリントを含む「ゼロから」の範囲はAUD 395–515だった。

価格と在庫は変動するため、公開時には日付を表示し、現在価格とは表現しない。既存工具や固定自転車があり、EMGを後回しにすれば費用は下がる。

---

[CONTENT ID: P2-MOUNT-01]

## ペダルへの装着：センサーと指標の意味を守る

FSRを柔らかいペダルカバーの下へ置く。感圧部上に20–30 mmの硬い荷重拡散板、下に2–5 mmのEVAを配置する。テールは端へ逃がし、引張りを防ぐ。初期は面ファスナーで交換可能にし、再現性を確認してから3Dスロットを設計する。

[IMAGE IMG-07] shoe、soft cover、force-spreading puck、FSR sensing area、EVA layer、pedal body、protected tail、connectorの分解断面図。点荷重とテールのせん断に赤い×印。

[CAPTION] FSRは荷重拡散とせん断保護が必要であり、装着方法自体が計測条件になる。

[ALT] 靴、カバー、荷重拡散板、FSR、EVA、ペダル本体、保護されたテールの分解図。

[CONTENT ID: P2-MOUNT-02]

## 触覚の装着：「どちら側か」を身体位置で伝える

振動モーターを左右足首外側の柔らかいストラップへ固定し、不快な骨突出部を避ける。配線をストラップへ沿わせ、外装入口でストレインリリーフする。強すぎる刺激ではなく、位置と短い波形で識別性をつくる。長時間振動は感覚順応とEMG汚染を起こし得るため避ける。

[CONTENT ID: P2-MOUNT-03]

## 筋と読み取り専用EMG：局所信号は全身動作ではない

ペダリングでは複数の下肢筋が異なるクランク位相で活動する。外側広筋（vastus lateralis）は膝伸展に関わり、表面EMGで扱われる代表的部位の一つだが、1チャンネルで脚全体の寄与やペダル力を説明することはできない。

身体図では大腿四頭筋、ハムストリングス、大殿筋、腓腹筋、前脛骨筋を背景として示し、「本プロトタイプは一つの例示的チャンネルのみを読む」と明記する。センサーはメーカーとSENIAMの一般原則に沿い、筋線維方向へ合わせ、ケーブルを固定する。実際の装着は関連経験を持つ人の指導下で行う。

SEN0240の乾式電極ストラップを大腿へ安全・安定して固定できない場合、初期版は前腕で静的信号経路だけを示し、脚EMGを今後の作業として記載する。

[IMAGE IMG-09] 下肢外側の簡略筋図。vastus lateralis、gluteus maximus、hamstrings、gastrocnemius、tibialis anteriorを表示。青い領域に「illustrative read-only sEMG channel」「not total leg force」。

[CAPTION] 1チャンネルsEMGは活動タイミングを示せるが、脚全体の機械的寄与は説明できない。

[ALT] 外側広筋上の読み取り専用sEMGを強調し、脚全体の力ではないと示す下肢筋図。

[SOURCE]

- [Electromyographic analysis of pedaling: a review](https://pubmed.ncbi.nlm.nih.gov/18093842/)
- [SENIAM placement and fixation](https://www.seniam.org/fixation.htm)
- [SENIAM vastus lateralis recommendation](https://seniam.org/quadricepsfemorisvastuslateralis.html)

[CONTENT ID: P2-MOUNT-04]

## Hallと機械装着：可動範囲へ部品を入れない

Hallブラケットは静止フレーム、磁石は回転部に置き、非接触間隔を確保する。磁石は機械固定と結束/テープの二重保持を行う。ハブ、サーボ、電源、USB配線はクランク範囲外へ置く。

紙、フォーム、結束バンドで寸法を決めてから、Hall/磁石マウント、サーボダイヤル外装、左右反転可能な足ノードクリップの三部品だけをCAD化する。2週間のために3Dプリンターは購入しない。

[IMAGE IMG-10] 左にHallと磁石の非接触装着、右にサーボポインターと独立5 V電源。可動禁止領域を半透明赤色で示す。

---

[CONTENT ID: P2-DATA-01]

## データが装置を通る順序

1. FSRを50–100 Hzで取得し、rawとEMAを保存；
2. 足ノードが20–40 msごとにID、番号、時刻、圧力を送信；
3. ハブが受信と欠損を監視し、Hallイベントで回転を閉じる；
4. 左右積分、`left_share`、個人差、回転有効性を計算；
5. 提示の必要性を判断し、左右/レベルを返送；
6. サーボが相対状態を表示；
7. USB SerialがPCへ送り、CSV/JSONを出力；
8. E2の過去軌跡に出所、条件、バージョンを保存する。

[CONTENT ID: P2-ALGO-01]

## 最小計算

```text
left_area  = 1回転内の校正済み左圧力の時間積分
right_area = 1回転内の校正済み右圧力の時間積分
left_share = left_area / (left_area + right_area)
delta      = left_share - baseline_left_share
```

総荷重不足、Hallタイムアウト、ノード欠損、過大なパケット損失では回転を無効とし、提示を出さない。初期許容範囲は60秒ベースラインの平均±1.5標準偏差などから始め、パイロットで調整する。医学基準ではない。

---

[CONTENT ID: P2-REUSE-01]

## 再利用01｜Smart Chair：センサーパイプラインだけを受け継ぐ

`qppd/smart-chair`はESP32 + FSR、個人tare、EMA、閾値、パルス触覚、シリアル操作、CSV、Fritzing、Fusion 360を実装済みである。

**Reuse**：10 kΩ分圧、tare/EMA、ノンブロッキング時間処理、出力テスト、CSV、MIT表示。  
**Adapt**：静的な座面左右差を1回転積分へ変更し、100サンプル平均を高速化。  
**Exclude**：姿勢分類、5枚FSR、背面flexセンサー、健康効果の主張。

[SOURCE] [qppd/smart-chair](https://github.com/qppd/smart-chair) — MIT

[CONTENT ID: P2-REUSE-02]

## 再利用02｜ESP-NOW：公式の複数デバイス例から始める

Espressifの公式例からpeer登録、送受信callback、broadcastを利用する。追加するのは`node_id`、`packet_seq`、時刻、圧力、故障フラグ、戻りの触覚指令である。片側電源を抜いた場合、500 ms以内に出力を停止する。

[SOURCE] [Espressif Arduino ESP-NOW公式資料](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/espnow.html)

[CONTENT ID: P2-REUSE-03]

## 再利用03｜ESP32 FTMS Server：Hallとマウントの考え方

`esp32-ftms-server`は固定自転車用Hallタコメーターで、`tachMount.stl`を含む。イベント、デバウンス、装着を参照し、完全なBluetooth FTMSは実装しない。

[SOURCE] [jamesjmtaylor/esp32-ftms-server](https://github.com/jamesjmtaylor/esp32-ftms-server) — MIT

[CONTENT ID: P2-REUSE-04]

## 再利用04｜Adafruit DRV2605 Library：既存触覚波形を使う

公式例でドライバとモーターを確認し、三つの短い波形を選ぶ。再配布時はMITライセンスと著者表示を残す。

[SOURCE] [Adafruit_DRV2605_Library](https://github.com/adafruit/Adafruit_DRV2605_Library) — MIT

[CONTENT ID: P2-REUSE-05]

## 再利用05｜Insole Pressure Sensor：多チャンネル化の将来案

BrillnovaのプロジェクトはESP32、MUX、片足最大16チャンネル、50 msフレーム、時刻、Python可視化、制作動画を含む。MVPでは使わず、将来の圧力ヒートマップ拡張として参照する。

CC BY-NC 4.0のため、表示付き非商用利用と改変は可能だが商用利用は禁止される。商業ポートフォリオや製品化では再確認が必要である。

[SOURCE] [Brillnova/Insole-Pressure-Sensor](https://github.com/Brillnova/Insole-Pressure-Sensor) — CC BY-NC 4.0

[CONTENT ID: P2-REUSE-06]

## 再利用06｜DFRobot EMG例：同じ型番の公式回路だけを使う

SEN0240 Wikiの校正、波形表示、動作カウント、乾式電極方向を利用し、共通時刻、番号、CSVを追加する。他のEMGモジュールの正負電源回路をSEN0240へコピーしない。

[SOURCE]

- [SEN0240 Wiki](https://wiki.dfrobot.com/sen0240/)
- [DFRobot Clever Rabbit Hat：EMG→サーボ](https://www.dfrobot.com/blog-1129.html)

[IMAGE IMG-11] 六つのオープンソースタイルをReuse / Adapt / Excludeに分け、PedalBalance Echoの具体的モジュールへ矢印で結ぶ。

[CAPTION] 迅速な制作とは無断コピーではなく、継承・変更・除外を明確にすることである。

---

[CONTENT ID: P2-BUILD-01]

## 毎日、見せられる証拠を残す14日間

ソフトウェアシミュレーションは常に研究ロジック全体を示し、実機モジュールが段階的に模擬入力を置き換える。物流や一つのセンサーが失敗しても、ケーススタディ全体は残る。

[IMAGE IMG-12] Sense、Connect、Compute、Return、Study、Documentの六レーンで14日を示し、各日に見える成果物を記載する。

[CONTENT ID: P2-BUILD-02]

### D1–D4｜システム化する前に信号を信頼できる状態へ

**D1**：調達、リポジトリ、BOM、リスクログ、実機なしシミュレーター。  
**D2**：FSR 1枚、raw波形、EMA、同一重量10回。  
**D3**：左右ノード、校正、手で交互に押すペダリング模擬。  
**D4**：ESP-NOW、番号、欠損率、電源断フェイルセーフ。

**証拠**：ブレッドボード、波形、校正表、通信ログ、切断動画。

[CONTENT ID: P2-BUILD-03]

### D5–D9｜信号を回転、フィードバック、画面へ

**D5**：Hallベンチテスト、低速装着、デバウンス、RPM。  
**D6**：均衡、左、右、無荷重、切断の記録データテスト。  
**D7**：触覚例、三波形、左右定位。  
**D8**：独立電源サーボと紙ベースラインダイヤル。  
**D9**：模擬/実機共通画面、状態、条件、エクスポート。

**証拠**：Hall装着、アルゴリズム結果、触覚表、ポインター動画、実データ画面。

[CONTENT ID: P2-BUILD-04]

### D10–D14｜EMG、実験条件、ポートフォリオ証拠

**D10**：静的EMG、包絡線、時間整合、振動アーチファクト。  
**D11**：実測CAD、Hall、サーボ外装、左右ノードクリップ。  
**D12**：C1ベースライン、視覚、連続、適応、無提示。  
**D13**：E2 past-self、PS-H、模擬MO-H、PS-V、NF、抵抗転移。  
**D14**：90秒動画、資料、CAD、辞書、ライセンス、失敗ログ。

**証拠**：EMG、STEP/STL、条件ログ、軌跡、転移記録、デモパッケージ。

---

[CONTENT ID: P2-GATE-01]

## 省略できない五つのテストゲート

1. 単体センサーが動いてから無線へ入れる。
2. 左右同一重量の反復を記録してからペダルへ装着する。
3. Hallが1回転1イベントになってから寄与を計算する。
4. 閉眼左右定位が8/10に達してから実験に入れる。
5. ノード切断後500 ms以内に出力が止まってから身体へ装着する。

失敗した場合は、最後に説明可能だった層へ戻る。成功に見せるために閾値を恣意的に変えたり、ログを隠したりしない。

---

[CONTENT ID: P2-DONTBUY-01]

## 2週間で完成させるために買わないもの

- DIY EMS/TENS刺激器と刺激電極；
- 商用パワーメーターペダル；
- 3Dプリンター；
- カスタムPCB；
- MVPでの16チャンネルインソール；
- 2台目EMG、オシロスコープ、クラウド；
- モバイルアプリ、アカウント、同期。

範囲管理も設計能力である。必要なのは検証可能な人—機械—人ループであり、機能の総量ではない。

---

[CONTENT ID: P2-NEXT-01]

## 次ページ：振動する装置を、どう研究へ変えるか

次ページでは、校正、C1の撤去、E2の過去自己再生、指標、安全、能力証拠を説明する。

**リンク文言**  
実験設計と証拠を見る →

[INTERACTION] BOMは10枚の展開カードにできる。通常は役割、数量、状態だけを表示し、選択時に技術的限界、出典、再利用判断を見せる。価格をページの中心にしない。

