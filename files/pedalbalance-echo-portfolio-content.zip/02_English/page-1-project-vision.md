# Page 1 | Project Vision

[PORTFOLIO NOTE] Headings, body copy, captions and short labels may be published. `[LAYOUT]`, `[IMAGE]`, `[INTERACTION]` and `[PORTFOLIO NOTE]` are production instructions and should not appear on the public page.

---

[CONTENT ID: P1-META-01]

**Page title**  
PedalBalance Echo | Returning Human Movement Through a Machine

**Page summary**  
A two-week embodied-interaction research prototype. Relative left–right pedal pressure and optional surface EMG enter three ESP32 nodes. The machine evaluates each complete pedal revolution against a personal baseline, then returns information through a visual interface, a physical pointer and side-specific ankle vibration. The same platform supports two questions: when guidance should fade, and whether a recorded version of one’s past bodily performance can guide the present self.

**Keywords**  
Embodied Interaction / Human Augmentation / Haptics / EMG / ESP32 / Cycling / Motor Learning / Past Self / Research through Making

---

[CONTENT ID: P1-HERO-01]

**Eyebrow**  
EMBODIED INTERACTION · RESEARCH PROTOTYPE · 14-DAY BUILD

[CONTENT ID: P1-HERO-02]

# When the body enters a machine, how should the machine return it?

[CONTENT ID: P1-HERO-03]

PedalBalance Echo is a stationary-cycling body-feedback prototype. It reads relative pressure contribution across a complete pedal revolution, detects deviations that persist beyond a personal baseline, and cues the corresponding side of the body through ankle vibration. It can also record a well-performed segment and reintroduce that bodily trajectory in a later practice session.

The system is not designed to take over the movement. It behaves more like a tactile mirror: sensing an action, interpreting a difference, preserving a trace of the past, and returning only enough information for the rider to act independently.

[CONTENT ID: P1-HERO-04]

**Key facts**

- 14 days from procurement to supervisor demonstration;
- 3 wireless nodes: left foot, right foot and central hub;
- 2 research questions: guidance withdrawal and past-self replay;
- 1 safety rule: no DIY EMS; bodily output is vibration;
- 0 medical claims: FSR, EMG and training observations remain prototype data.

[LAYOUT] Place the title, summary and two entry actions on the left; place IMG-01 on the right. Run the five facts as a narrow strip below the hero.

[IMAGE IMG-01] A participant seated at a compact stationary pedal exerciser. Fine callout lines connect the two pedals, ankle haptics, central physical pointer and laptop. The body, machine and returned feedback should read as one loop.

[CAPTION] Pedalling is sensed, interpreted across complete revolutions, and returned through visual, physical and tactile channels.

[ALT] A participant uses a stationary pedal exerciser while left–right pressure, cadence and optional EMG feed a central system that returns ankle vibration.

---

[CONTENT ID: P1-PROBLEM-01]

## The challenge was not another dashboard, but a way for information to re-enter action

Cycling interfaces commonly translate bodily performance into numbers, curves and left–right bars. These displays are legible, but they ask the rider to move attention away from the legs, interpret a visual difference, and translate it back into a bodily adjustment.

If information originates on the left or right side, could it return to that same side? Should the system remain silent when an error lasts only for an instant? If guidance never disappears, is the rider learning—or merely following the device?

These questions reposition the project from measurement to embodied learning:

1. Where should information return?
2. When should the machine intervene?
3. When must the machine withdraw?

[CONTENT ID: P1-PROBLEM-02]

## A cycling-specific mistake: the two legs are not supposed to load the pedals at the same instant

Pedalling is cyclical. The two legs alternate roles across a revolution, so an instantaneous difference can be completely normal. Comparing two FSR readings frame by frame would mistake normal alternation for asymmetry.

PedalBalance Echo uses a Hall event to delimit one complete revolution, integrates the left and right pressure traces within that interval, and only then calculates relative contribution. This does not turn low-cost FSRs into precision instruments; it makes the proxy metric consistent with the temporal structure of the action.

The public claim must remain “relative pressure-contribution proxy.” It is not cycling power, crank torque, muscle force or a clinical asymmetry measure.

[IMAGE IMG-03] A four-frame sequence: natural pedalling, a persistent left deviation, a right-side cue, and active return to baseline. Each frame represents a full revolution rather than a single pressure sample.

[CAPTION] The system ignores momentary alternation and responds only when deviation persists across complete revolutions.

[ALT] Four stages show natural pedalling, persistent deviation, a side-specific vibration cue and active recovery.

---

[CONTENT ID: P1-INSIGHT-01]

## The location of feedback can carry the message

If left-side contribution falls, the left ankle vibrates. If the right side falls, the right ankle vibrates. When the rider returns to the personal tolerance band, vibration stops.

The body location encodes “which side needs attention,” avoiding a learned code of arbitrary sounds or colours. The vibration neither pushes the leg nor completes the action. It remains a local, optional cue; the adjustment is voluntary.

This mapping only works if left and right are reliably distinguishable. Each session therefore begins with ten eyes-closed localisation trials. At least eight must be identified correctly. If not, the mounting position is changed before intensity is increased.

---

[CONTENT ID: P1-LOOP-01]

## Human → Machine → Human → Learning

The abstract proposition becomes four testable stages.

### 1. Human: the body produces information

The feet load the pedals and the crank completes a periodic movement. An optional read-only surface-EMG channel records timing from one target muscle.

### 2. Machine: the device forms an interpretation

Two foot nodes sample pressure and send packets through ESP-NOW. Hall events divide revolutions; the hub calculates integrated contribution, baseline deviation, data validity and cue level.

### 3. Human: information returns to the body

A dashboard makes the signal inspectable, a servo pointer gives the calculation a physical state, and side-specific ankle vibration returns “where to attend” to the body.

### 4. Learning: the machine steps away

Guidance is removed to test unaided performance. On the following day, resistance or cadence changes to test transfer. Assistance-on performance is not treated as learning unless something remains after the assistance is gone.

[IMAGE IMG-02] A circular information diagram with Body Signals, Sensing, Cycle Model, Haptic/Mechanical Feedback, Active Correction, and Retention & Replay. Place PedalBalance Echo in the centre.

[ANNOTATION] Beside Sensing: “2× FSR + Hall + optional read-only EMG.” Beside output: “ankle vibration + servo pointer + visual dashboard.”

[CAPTION] The goal of the loop is not stronger machine control, but a bodily strategy that can remain when the machine withdraws.

[ALT] A six-stage loop moves from bodily signals to sensing, machine interpretation, feedback, active correction, retention and replay.

---

[CONTENT ID: P1-SCENARIO-01]

## A typical session

**1. Meet the device.** The rider checks that sensors, cables, magnet and batteries are outside the moving path. The system demonstrates left and right vibration.

**2. Establish a personal baseline.** After unloaded and equal-weight sensor checks, the rider pedals naturally for 60 seconds. The system records personal distribution and variability rather than imposing 50:50 as a medical norm.

**3. Respond only to persistence.** At the end of each valid revolution, the hub calculates contribution. A weak cue appears only after three consecutive out-of-band revolutions; it escalates only if the deviation continues.

**4. Let the rider solve the problem.** The rider changes the movement. Vibration stops immediately once the value returns to the tolerance band.

**5. Remove the machine.** Guidance is disabled and unaided performance is recorded.

**6. Encounter a past self.** A previously recorded high-quality segment is returned through touch or vision in a later session, allowing its source and delivery channel to be compared.

---

[CONTENT ID: P1-RESEARCH-01]

## C1 | How should guidance fade so that independent skill remains?

C1 separates performance from learning. Better behaviour while a cue is active demonstrates assistance; learning requires unaided retention and transfer to a changed task.

The same apparatus compares:

- a visual left–right display;
- continuous bodily vibration;
- feedback that fades on a fixed schedule;
- adaptive feedback that appears only after persistent error.

The primary interest is not the smallest error during training. It is immediate no-feedback performance, 24-hour retention, and transfer under a changed resistance. This preserves the mechanism behind adaptive-EMS research—reducing intervention as performance improves—while translating it into a low-risk haptic platform.

[CONTENT ID: P1-RESEARCH-02]

## E2 | Can the body data of a past self re-enter present action?

Saving a historical curve is easy. Calling it a past self becomes meaningful only when source identity and bodily output are separated.

The project records a strong segment of relative contribution and cadence, then compares:

- **PS-H**: Past Self + Haptic;
- **MO-H**: performance-matched Other + Haptic;
- **PS-V**: Past Self + Visual;
- **NF**: No History.

In a one-person prototype, MO-H must be labelled `simulated_matched_other`. It cannot be presented as data from a real second person. These controls turn “human → machine → human” into a falsifiable structure rather than a narrative label.

[IMAGE IMG-04] A two-axis map. Horizontal: Guidance Source—External to Past Self. Vertical: Output Channel—Visual to Embodied. Mark C1 around feedback strategy and withdrawal, and E2 around source identity and cross-time replay.

[CAPTION] C1 asks when the machine should withdraw; E2 asks whose embodied guidance is being returned.

[ALT] A research-space map separates external and past-self guidance from visual and embodied output, locating C1 and E2.

---

[CONTENT ID: P1-RELATED-01]

## Learning the research mechanism without reproducing the risk

Three lines of work informed the concept.

**Adaptive Electrical Muscle Stimulation Improves Muscle Memory (CHI 2025)** changes guidance between demonstration, correction and warning based on learner error, and evaluates unassisted recall. PedalBalance Echo retains the adaptive-withdrawal structure while replacing stimulation with vibration.

**My(o) Action (CHI 2026)** uses EMG as an early sign of voluntary intention before combining it with stimulation. This prototype borrows only the idea that bodily signals can enter a system before an obvious movement is complete. Optional EMG is time-aligned for inspection; it does not control cues.

**bioSync (CHI 2017)** transmits one person’s EMG intensity to another body. PedalBalance Echo changes the receiver to a future self: a bodily trace is stored with provenance and returned during a later task.

[SOURCE]

- [Adaptive Electrical Muscle Stimulation Improves Muscle Memory](https://lab.plopes.org/published/2025-CHI-AdaptiveEMS.pdf)
- [My(o) Action: Accelerating Voluntary Actions via Electromyography and Muscle Stimulation](https://lab.plopes.org/published/2026-CHI-MyoAction.pdf)
- [bioSync: A Paired Wearable Device for Blending Kinesthetic Experience](https://doi.org/10.1145/3025453.3025829)
- [Design Guideline for Developing Safe Systems that Apply Electricity to the Human Body](https://doi.org/10.1145/3184743)

---

[CONTENT ID: P1-DESIGN-01]

## Four design principles

### Bodily correspondence

Feedback returns to the side from which the relevant difference originated. Location carries meaning.

### Personalisation without prescribing symmetry

Natural distribution and variability are measured before a prototype tolerance is defined. A 50:50 split is not treated as a medical standard.

### Minimum necessary intervention

One unusual revolution is ignored. Three persistent revolutions trigger a cue. Recovery stops it. Training is followed by guidance withdrawal.

### Traceable decisions

Every cue maps to a `cycle_id`, valid sensor state, rule and study condition. A cue that cannot be explained does not belong in experimental data.

---

[CONTENT ID: P1-SCOPE-01]

## Safety is part of the architecture, not an appendix

EMS, TENS, FES and EMG are not interchangeable. EMS/FES send current into the body and may actuate movement; EMG reads the small electrical activity produced by muscle. This two-week project does not reproduce laboratory EMS hardware.

The boundary is intentionally rewritten:

- body input: pressure, revolution events and optional read-only EMG;
- machine output: interface, servo pointer and side-specific vibration;
- environment: low-speed stationary indoor pedalling;
- research target: interaction mechanism and feasibility, not treatment;
- human testing: the maker begins with a low-risk self-test; other participants require supervisor and ethics guidance.

This translation does not abandon EMS research. It demonstrates the ability to identify the questions worth reproducing: intention, feedback timing, personal calibration, agency, withdrawal, retention and transfer.

---

[CONTENT ID: P1-CONTRIBUTION-01]

## What the project is meant to demonstrate

Novelty is not the primary claim. PedalBalance Echo is a capability-through-making project: can I move from literature and open-source selection to circuit assembly, embedded logic, wireless protocol, mechanical feedback, 3D enclosure planning, data logging, experimental controls and an honest account of limitations within two weeks?

The portfolio outcome is not a vibrating ankle strap. It is an auditable chain:

> Research question → technical choice → bodily mapping → prototype rule → data log → unaided test → reflection and next step.

---

[CONTENT ID: P1-NEXT-01]

## Next: how was the body loop made?

The next page breaks down the three ESP32 nodes, complete bill of materials, body and bicycle mounting, open-source components, 14-day build sequence and non-negotiable test gates.

**Link copy**  
Explore the prototype and build process →

[INTERACTION] At the end of the page, show a compact three-node preview. Selecting Left Foot, Right Foot or Hub reveals one sentence and links to the corresponding Page 2 section. Do not expand the full BOM on Page 1.

