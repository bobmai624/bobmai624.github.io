# Page 2 | Prototype & Making

[PORTFOLIO NOTE] This page should read as an account of turning a research question into a debuggable apparatus—not as a shopping catalogue. Explain the role of each part before showing its source.

---

[CONTENT ID: P2-META-01]

**Page title**  
Prototype & Making | From Three Development Boards to a Body Loop

**Page summary**  
PedalBalance Echo combines three XIAO ESP32-C3 boards, two FSRs, a Hall revolution sensor, bilateral haptics and a physical pointer. Existing libraries, tutorials and open-source projects provide the infrastructure; each module is tested in isolation before wireless integration.

---

[CONTENT ID: P2-HERO-01]

# Turning a research question into an apparatus that can fail one module at a time

The two-week schedule ruled out rebuilding motor drivers, wireless protocols or EMG front ends from scratch. I divided the system into left-foot, right-foot and central-hub nodes with narrow responsibilities. Mature sensing examples, ESP-NOW and haptic libraries handle infrastructure, leaving time for the cycling-specific decisions: complete-revolution modelling, body mapping, guidance withdrawal and traceable study logs.

**Lead line**  
Build small. Test one signal at a time. Integrate only after every module can fail safely.

[IMAGE IMG-05] A neutral-background flat lay of three XIAO boards, two FSRs, two DRV2605L boards, three vibration motors, Hall sensor, magnets, servo, EMG module, two batteries and the pedal exerciser. Label only name and quantity.

[CAPTION] A modular, low-cost body interface: pressure and revolution events enter the machine; tactile and mechanical states return to the rider.

[ALT] The main PedalBalance Echo parts grouped as sensing, computation, output and optional validation components.

---

[CONTENT ID: P2-ARCH-01]

## Three-node architecture

```text
Left pressure + optional EMG → Left node  ─┐
                                           ├─ ESP-NOW → Hub → USB → prototype/data
Right pressure               → Right node ─┘              ├─ Hall: revolution boundary
                                                           └─ Servo: physical pointer

Hub → ESP-NOW → Left/Right nodes → side-specific ankle vibration
```

This arrangement removes loose wires across the crank. Foot nodes run on batteries; the hub remains on the pedal frame and connects to the computer through USB. Each foot has its own DRV2605L, avoiding two fixed-address haptic controllers on one I2C bus.

[IMAGE IMG-06] A three-node diagram using separate colours for sensing, computation and feedback. Label every edge: Analog ADC, ESP-NOW, I2C, USB Serial and PWM.

[CAPTION] Clear module boundaries allow pressure, radio, revolution sensing, haptics and interface logic to be tested independently.

[ALT] Left and right foot nodes connect wirelessly to a hub that reads a Hall sensor, drives a servo and connects to a computer.

[CONTENT ID: P2-ARCH-02]

### Left-foot node

- XIAO ESP32-C3;
- one FSR and 10 kΩ divider;
- one DRV2605L and 10 mm vibration motor;
- one protected 3.7 V LiPo;
- optional plug-in SEN0240 EMG;
- 50–100 Hz pressure sampling and 25–50 Hz packet transmission;
- local haptic shutdown when hub commands disappear.

[CONTENT ID: P2-ARCH-03]

### Right-foot node

- the same pressure, haptic and power structure without EMG;
- independent node ID, sequence counter and battery;
- shared firmware with a `LEFT` or `RIGHT` configuration rather than two diverging codebases.

[CONTENT ID: P2-ARCH-04]

### Central hub

- XIAO ESP32-C3 connected to the computer via USB data cable;
- non-latching Hall sensor and crank magnet;
- 9 g servo and a cardboard or printed balance dial;
- packet reception, loss monitoring, revolution segmentation, metric calculation, cue transmission and serial logging;
- separate 5 V servo supply with common ground; never power a servo from a GPIO.

---

[CONTENT ID: P2-HW-01]

## 01 | XIAO ESP32-C3: one computing core across all three nodes

The 21 × 17.8 mm board combines an ESP32-C3, Wi-Fi, BLE, USB-C, I2C, PWM, ADC and lithium-battery management in a wearable-scale format. Official documentation lists four ADC inputs; the prototype prioritises A0/A1/A2 on ADC1 and avoids A3/ADC2, which the manufacturer flags for potentially unreliable analog sampling.

**Quantity:** 3, with an optional fourth spare.  
**Role:** two wireless foot nodes and one calculating hub.  
**Reason to standardise:** one board definition, one programming workflow and interchangeable spares.

[IMAGE] Use official front/back photographs only as selection references. For publication, replace them with personal photographs including a ruler or coin for scale.

[SOURCE]

- [Seeed Studio XIAO ESP32-C3 official guide](https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/)
- [Australian purchasing reference: Core Electronics](https://core-electronics.com.au/seeed-studio-xiao-esp32c3-tiny-mcu-board-with-wi-fi-and-ble-battery-charge-supported-power-efficiency-and-rich-interface.html)

[CONTENT ID: P2-HW-02]

## 02 | Interlink 402 FSR: observing relative pressure change

An FSR is a thin-film resistor whose resistance changes under load. It is inexpensive and easy to connect to an ADC, but non-linearity, hysteresis, mounting and unit variation prevent power-meter claims.

Each FSR forms a divider with 10 kΩ. The same weight is applied to both channels for repeated checks. Raw, filtered and calibrated values remain available; the system never converts the readings directly into watts.

**Quantity:** 2, plus one optional spare.  
**Mechanical rule:** prevent lateral shear on the tail and use a socket or terminal rather than soldering directly to the film tabs.

[SOURCE]

- [Little Bird: Interlink 402 FSR](https://littlebirdelectronics.com.au/products/round-force-sensitive-resistor-fsr-interlink-402)
- [Adafruit FSR guide](https://learn.adafruit.com/force-sensitive-resistor-fsr)

[CONTENT ID: P2-HW-03]

## 03 | DRV2605L: reusing a purpose-built haptic driver

The I2C DRV2605L controls ERM and LRA haptic motors and includes effects such as clicks and ramps. Adafruit supplies wiring, examples and an Arduino library. One board per foot provides three short, distinguishable patterns for weak, medium and strong cues without driving a motor directly from a GPIO.

**Quantity:** 2.  
**Scope:** three short patterns only; no continuous high-duty vibration.

[SOURCE]

- [Adafruit DRV2605L guide](https://learn.adafruit.com/adafruit-drv2605-haptic-controller-breakout/overview)
- [Adafruit DRV2605 Arduino Library](https://github.com/adafruit/Adafruit_DRV2605_Library)
- [Australian purchasing reference](https://core-electronics.com.au/adafruit-drv2605l-haptic-motor-controller.html)

[CONTENT ID: P2-HW-04]

## 04 | 10 mm vibration motors: returning left–right meaning at the ankle

Coin-type ERM motors sit on the outer left and right ankle straps. Mounting them under the pedals would blur localisation and increase mechanical contamination of the pressure signal.

**Quantity:** 3—one per side and one spare.  
**Mapping:** lower left contribution → left cue; lower right contribution → right cue; recovery → silence.  
**Pre-test:** at least 8/10 correct left–right identifications with eyes closed.

[SOURCE] [Little Bird: Mini Vibration Motor](https://littlebirdelectronics.com.au/products/mini-vibration-motor-10-2-7mm?collection=dfrobot)

[CONTENT ID: P2-HW-05]

## 05 | Hall sensor and magnet: a boundary for every full revolution

A non-latching Hall sensor generates an event when the crank-mounted magnet passes. Adjacent events define one `cycle_id`; their interval also estimates cadence.

**Quantity:** 2 Hall sensors, one as a spare, plus a small magnet pack.  
**Mechanical rule:** non-contact placement, two independent retention methods for the magnet, and no cable within the crank path.

[SOURCE]

- [AH1815 non-latching Hall sensor](https://core-electronics.com.au/hall-effect-sensor-ah1815-non-latching.html)
- [ESP32 stationary-bike Hall/FTMS example](https://github.com/jamesjmtaylor/esp32-ftms-server)

[CONTENT ID: P2-HW-06]

## 06 | 9 g servo: giving the machine a physical state

A small servo moves a pointer around the personal baseline. It is a tangible display, not a calibrated instrument. The first dial is cardboard; a printed enclosure follows only after dimensions are stable. The servo has a separate 5 V supply, shares ground with the hub and uses software angle limits.

[SOURCE] [Jaycar 9 g Micro Servo](https://www.jaycar.com.au/arduino-compatible-9g-micro-servo-motor/p/YM2758)

[CONTENT ID: P2-HW-07]

## 07 | SEN0240: an optional read-only surface-EMG channel

The DFRobot/OYMotion SEN0240 combines dry electrodes with amplification and filtering. Its analog output is referenced around 1.5 V and spans 0–3.0 V; the documented supply range is 3.3–5.5 V.

Its role is to make muscle activity visible in time and to demonstrate a body-input pathway. It does not trigger bilateral cues and cannot diagnose fatigue, injury, strength or correctness. Cable motion, contact, crosstalk and vibration artefacts remain explicit limitations.

**Quantity:** 1.  
**First use:** compare rest and gentle static contraction before any low-speed pedalling test.

[SOURCE]

- [DFRobot SEN0240 official documentation](https://wiki.dfrobot.com/sen0240/)
- [Australian purchasing reference](https://core-electronics.com.au/gravity-analog-emg-sensor-by-oymotion.html)

[CONTENT ID: P2-HW-08]

## 08 | LiPo and power: removing cables from the crank area

Each foot node uses a protected 3.7 V LiPo. Polarity is checked before connection. Charging happens off-body on a non-flammable surface; damaged, swollen or hot cells are retired immediately. The hub is USB-powered and the servo uses a separate 5 V / 2 A source. USB power banks remain the safer bench-stage alternative.

[SOURCE]

- [XIAO ESP32-C3 Battery Usage](https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/#battery-usage)
- [400 mAh protected LiPo reference](https://core-electronics.com.au/polymer-lithium-ion-battery-400mah-38456.html)

[CONTENT ID: P2-HW-09]

## 09 | Pedal exerciser: containing the study in a controlled setting

A compact pedal exerciser with straps and adjustable resistance is sufficient. The build does not require a road bicycle, advanced trainer or commercial power meter. Testing begins at low resistance on a non-slip surface with a stable seated posture.

[SOURCE] [Everfit Mini Pedal Exerciser reference](https://www.kmart.com.au/product/everfit-pedal-exerciser-mini-exercise-bike-cross-trainer-under-desk-bike-black-110070790/)

[CONTENT ID: P2-HW-10]

## 10 | Tools and consumables: moving from breadboard to wearable assembly

The basic tool set includes a soldering iron, multimeter, solder sucker, cutters, stripper, iron stand, eye protection and USB-C data cables. Consumables include small breadboards, 10 kΩ/1 kΩ/220 Ω resistors, 100 nF capacitors, flexible wire, sockets or terminals, heat-shrink, hook-and-loop straps, EVA foam, force-spreading discs, cable ties and M2/M3 hardware.

The portfolio should show continuity checks, early breadboards, soldering, strain relief, rework and the final modules—not only a polished endpoint.

[SOURCE] [Jaycar soldering starter kit with multimeter](https://www.jaycar.com.au/25w-soldering-iron-starter-kit-with-dmm/p/TS1652)

---

[CONTENT ID: P2-COST-01]

## A budget is a scope-control record, not a live quotation

The planning snapshot dated 13 August 2026 placed the major items—three XIAO boards, bilateral pressure/haptics, Hall sensing, servo, EMG, tools and pedal exerciser—at approximately AUD 344.65. With consumables, shipping and optional printing, the from-zero envelope was AUD 395–515.

Prices and availability change. The portfolio must show the date and avoid presenting the estimate as a current offer. Existing tools, a stationary bike and postponing EMG substantially reduce the minimum cost.

---

[CONTENT ID: P2-MOUNT-01]

## Pedal mounting: protect the sensor and the meaning of the measurement

The FSR sits below a soft pedal cover. A 20–30 mm rigid force-spreading disc sits above the sensing area, with 2–5 mm EVA beneath it. The film tail exits along the pedal edge with strain relief. Early versions remain removable with hook-and-loop material; a printed slot is designed only after repeatability is established.

[IMAGE IMG-07] Exploded pedal section: shoe, soft cover, force-spreading puck, FSR sensing area, EVA layer, pedal body, protected tail and connector. Mark sharp point loading and shear on the tail with red crosses.

[CAPTION] FSR mounting needs force spreading and shear protection; installation is part of the measurement and must be documented.

[ALT] An exploded pedal section shows the shoe, cover, force spreader, FSR, EVA and protected sensor tail.

[CONTENT ID: P2-MOUNT-02]

## Haptic mounting: encoding “which side” in body location

Motors sit on soft straps at the outer left and right ankle, away from uncomfortable bony points. Wires are fixed along the strap and strain-relieved before entering the enclosure. Placement—not excessive intensity—creates distinct meaning. Long vibration is avoided because it promotes adaptation and can contaminate optional EMG.

[CONTENT ID: P2-MOUNT-03]

## Muscle context and read-only EMG: one local signal is not the whole action

Pedalling recruits several lower-limb muscles at different crank phases. The vastus lateralis contributes to knee extension and is a common surface-EMG site, but one channel cannot represent total leg contribution or mechanical pedal force.

The body diagram should label quadriceps, hamstrings, gluteus maximus, gastrocnemius and tibialis anterior, while highlighting that the prototype observes only one illustrative channel. Sensor orientation follows manufacturer and SENIAM principles: aligned with fibre direction, mechanically fixed and protected from cable pull. Practical placement should be supervised by someone with relevant experience.

If the SEN0240 dry-electrode strap cannot be mounted safely and consistently on the thigh, the first build demonstrates the signal chain statically on the forearm and lists leg EMG as planned work.

[IMAGE IMG-09] A simplified lateral leg diagram labels the major muscles. A blue area over the vastus lateralis reads “illustrative read-only sEMG channel” and “not total leg force.”

[CAPTION] A single surface-EMG channel can illustrate timing, but it cannot explain the mechanical contribution of an entire leg.

[ALT] A lateral-leg muscle diagram highlights one read-only surface-EMG channel over the vastus lateralis and states that it is not total leg force.

[SOURCE]

- [Electromyographic analysis of pedaling: a review](https://pubmed.ncbi.nlm.nih.gov/18093842/)
- [SENIAM placement and fixation](https://www.seniam.org/fixation.htm)
- [SENIAM vastus lateralis recommendation](https://seniam.org/quadricepsfemorisvastuslateralis.html)

[CONTENT ID: P2-MOUNT-04]

## Hall and mechanical mounting: nothing enters the moving envelope

The Hall bracket sits on the stationary frame and the magnet on a rotating part with a non-contact gap. The magnet receives mechanical retention plus a second tie or tape. Hub, servo, power and USB cable remain outside the crank envelope.

Foam, card and ties establish dimensions before three small CAD parts are made: Hall/magnet mounts, a servo dial enclosure and mirrored foot-node clips. Buying a 3D printer is outside the two-week scope.

[IMAGE IMG-10] Left: non-contact Hall and magnet installation. Right: servo pointer and independent 5 V power. Mark the moving exclusion arc in translucent red.

---

[CONTENT ID: P2-DATA-01]

## How data travels through the apparatus

1. FSRs sample at 50–100 Hz and preserve raw and EMA values.
2. Foot nodes send node ID, sequence and timestamped values every 20–40 ms.
3. The hub tracks reception and loss; a Hall event closes the revolution.
4. The hub calculates integrals, `left_share`, personal-baseline deviation and validity.
5. The controller decides whether a cue is justified and sends side/level commands.
6. The servo renders the current relative state.
7. USB Serial feeds the interface and CSV/JSON export.
8. Past traces retain provenance, condition and version metadata for E2 replay.

[CONTENT ID: P2-ALGO-01]

## Minimal calculation

```text
left_area  = time integral of calibrated left pressure within one revolution
right_area = time integral of calibrated right pressure within one revolution
left_share = left_area / (left_area + right_area)
delta      = left_share - baseline_left_share
```

Low total load, Hall timeout, node loss or excessive packet loss invalidates the revolution and suppresses cues. A starting tolerance may use the 60-second baseline mean ±1.5 standard deviations, then be adjusted through pilots. It is a prototype rule, not a medical standard.

---

[CONTENT ID: P2-REUSE-01]

## Reuse 01 | Smart Chair: adopt the sensor pipeline, not the seating task

`qppd/smart-chair` already implements ESP32 + FSR sensing, per-user tare, EMA, thresholds, pulsed haptics, serial controls, CSV logging, Fritzing wiring and Fusion 360 models.

**Reuse:** 10 kΩ dividers, tare/EMA, non-blocking timing, actuator tests, CSV logger and MIT attribution.  
**Adapt:** replace static seat imbalance with complete-revolution integration; shorten its 100-sample averaging for faster pedalling.  
**Exclude:** posture classification, five-seat-sensor topology, flex sensors and health claims.

[SOURCE] [qppd/smart-chair](https://github.com/qppd/smart-chair) — MIT

[CONTENT ID: P2-REUSE-02]

## Reuse 02 | ESP-NOW: begin with official multi-device examples

Espressif documents peer registration, send/receive callbacks and multiple-device broadcast. The project adds `node_id`, `packet_seq`, timestamps, pressure and fault flags, plus return haptic commands. Pulling power from either foot node must silence output within 500 ms.

[SOURCE] [Espressif Arduino ESP-NOW documentation](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/espnow.html)

[CONTENT ID: P2-REUSE-03]

## Reuse 03 | ESP32 FTMS Server: adopt Hall cadence and mount logic

`esp32-ftms-server` is an ESP32 Hall tachometer for a stationary bicycle and includes `tachMount.stl`. The prototype reuses event/debounce and mounting concepts, not the complete Bluetooth FTMS feature set.

[SOURCE] [jamesjmtaylor/esp32-ftms-server](https://github.com/jamesjmtaylor/esp32-ftms-server) — MIT

[CONTENT ID: P2-REUSE-04]

## Reuse 04 | Adafruit DRV2605 Library: use existing haptic effects

The official example verifies the driver and motor before three short patterns are selected. Redistribution retains the MIT licence and author notice.

[SOURCE] [Adafruit_DRV2605_Library](https://github.com/adafruit/Adafruit_DRV2605_Library) — MIT

[CONTENT ID: P2-REUSE-05]

## Reuse 05 | Insole Pressure Sensor: a multi-channel future path

Brillnova’s project combines ESP32, a multiplexer, up to 16 channels per foot, 50 ms frames, timestamps, Python visualisation and a build video. It informs a future pressure-heatmap upgrade, not the two-sensor MVP.

Its CC BY-NC 4.0 licence permits attributed non-commercial use and modification but prohibits commercial use. Commercial portfolio or product use requires a fresh licence decision.

[SOURCE] [Brillnova/Insole-Pressure-Sensor](https://github.com/Brillnova/Insole-Pressure-Sensor) — CC BY-NC 4.0

[CONTENT ID: P2-REUSE-06]

## Reuse 06 | DFRobot EMG examples: follow the exact sensor documentation

The SEN0240 Wiki provides calibration, waveform, action-count and dry-electrode orientation examples. PedalBalance Echo only adds the shared timestamp, sequence and CSV schema. Power circuits from unrelated EMG modules must not be copied onto SEN0240.

[SOURCE]

- [SEN0240 Wiki](https://wiki.dfrobot.com/sen0240/)
- [DFRobot Clever Rabbit Hat: EMG-to-servo demonstration](https://www.dfrobot.com/blog-1129.html)

[IMAGE IMG-11] Six open-source tiles, each divided into Reuse / Adapt / Exclude. Arrows connect specific modules to PedalBalance Echo rather than displaying logos alone.

[CAPTION] Speed comes from explicit adaptation: knowing what to inherit, what to rewrite and what not to carry forward.

---

[CONTENT ID: P2-BUILD-01]

## A 14-day build in which every day leaves visible evidence

The build follows two tracks. A software simulation always explains the full study logic; hardware modules progressively replace simulated inputs. Logistics or one failed sensor therefore cannot erase the case study.

[IMAGE IMG-12] A 14-day timeline across Sense, Connect, Compute, Return, Study and Document swimlanes. Each day names a visible artefact, not merely a task.

[CONTENT ID: P2-BUILD-02]

### D1–D4 | Make signals trustworthy before assembling a system

**D1:** procurement, repository, BOM, risk log and hardware-free simulator.  
**D2:** one FSR, raw trace, EMA and ten equal-weight repetitions.  
**D3:** bilateral nodes, calibration and alternating hand-press cycling simulation.  
**D4:** ESP-NOW, packet sequence, loss statistics and power-removal fail-safe.

**Evidence:** breadboard photographs, traces, calibration table, radio logs and disconnect video.

[CONTENT ID: P2-BUILD-03]

### D5–D9 | Turn signals into revolutions, feedback and an interface

**D5:** Hall bench test, low-speed mounting, debounce and RPM.  
**D6:** recorded-data tests for balanced, left, right, unloaded and disconnected cases.  
**D7:** haptic examples, three patterns and left–right localisation.  
**D8:** independently powered servo and cardboard baseline dial.  
**D9:** one interface for simulated and hardware data, status, conditions and export.

**Evidence:** Hall installation, algorithm results, haptic table, pointer video and live interface.

[CONTENT ID: P2-BUILD-04]

### D10–D14 | Add EMG, study conditions and portfolio evidence

**D10:** static EMG, envelope, timing and vibration-artifact flags.  
**D11:** measured CAD for Hall mount, servo enclosure and mirrored node clips.  
**D12:** C1 baseline, visual, continuous, adaptive and no-feedback self-test.  
**D13:** E2 past-self recording, PS-H, simulated MO-H, PS-V, NF and resistance transfer.  
**D14:** 90-second video, documentation, CAD, dictionary, licences and failure log.

**Evidence:** EMG trace, STEP/STL, condition logs, trace files, transfer recording and demonstration pack.

---

[CONTENT ID: P2-GATE-01]

## Five gates that cannot be skipped

1. A sensor works independently before it joins the radio network.
2. Equal-weight left–right repetition is recorded before pedal mounting.
3. Hall produces one event per revolution before contribution is calculated.
4. Eyes-closed localisation reaches 8/10 before haptics enter a study.
5. Any node disconnect silences output within 500 ms before body-worn use.

Failure returns the build to the last defensible layer. Thresholds are not inflated and logs are not hidden to make a demonstration appear successful.

---

[CONTENT ID: P2-DONTBUY-01]

## Deliberate exclusions that keep the project finishable

- DIY EMS/TENS stimulators and stimulation electrodes;
- commercial power-meter pedals;
- a 3D printer;
- custom PCB fabrication;
- a 16-channel insole in the MVP;
- a second EMG unit, oscilloscope or cloud backend;
- mobile apps, accounts or cloud synchronisation.

Scope control is part of the engineering. The required outcome is a verifiable human–machine–human loop, not every possible feature.

---

[CONTENT ID: P2-NEXT-01]

## Next: how does this become more than a device that vibrates?

The final page turns the apparatus into a study: calibration, C1 withdrawal, E2 past-self replay, metrics, safety and inspectable capability evidence.

**Link copy**  
Explore the experiment and evidence →

[INTERACTION] The BOM may become ten expandable cards. Keep role, quantity and status visible; reveal technical boundaries, sources and reuse decisions on selection. Do not let live pricing dominate the page.

