# Page 3 | Experiment & Capabilities

[PORTFOLIO NOTE] Distinguish planned research, a maker self-test and a formal participant study. Charts based on simulated data must say so directly.

---

[CONTENT ID: P3-META-01]

**Page title**  
Experiment & Capabilities | From Working Prototype to Falsifiable Demonstration

**Page summary**  
One apparatus supports two directions. C1 compares feedback-withdrawal strategies through unaided retention and transfer. E2 separates past-self identity, matched-other trajectories, visual replay and no-history practice. Behavioural measures remain linked to engineering quality and build evidence.

---

[CONTENT ID: P3-HERO-01]

# The prototype matters only if its research question can be inspected

A vibration cue can immediately draw attention to one side; that does not prove a learnt bodily strategy. A “past self” label can make a historical curve feel significant; that does not prove the source has a unique effect.

PedalBalance Echo therefore centres withdrawal, controls and provenance. What remains when the cue disappears? Does it transfer when the task changes? Does a quality-matched trajectory from another source behave differently? What changes when the same history is visual rather than bodily?

[IMAGE IMG-13] A sequence from Safety Check through Calibration, Baseline, Training, No-feedback Test, 24h Retention, Transfer, Replay and Export. Training and Replay branch into C1/E2 and rejoin at Export.

[CAPTION] Training is only one stage. Unaided tests, transfer and source controls determine what the system can claim.

[ALT] The study flow moves from safety and calibration through training, no-feedback assessment, retention, transfer, replay and export.

---

[CONTENT ID: P3-FRAME-01]

## One question connects both topics

> Should embodied guidance come from an external system or a past self, and when should it withdraw so that the learner owns the resulting skill?

C1 asks **when to withdraw**: continuously, on a time-based fade, or only after persistent error?

E2 asks **whose trace is returned**: a past self, a matched other, or an identity-free visual trajectory?

Both questions share input, output, logging and the cycling task. One two-week platform can therefore demonstrate the complete method without building two unrelated devices.

---

[CONTENT ID: P3-CAL-01]

## Calibration: understand device variation before interpreting bodily variation

### A. Unloaded check

Record ten seconds without pedal contact. Saturated, frozen or discontinuous ADC values stop the session.

### B. Equal-weight repetition

Apply the same object to each force-spreading disc ten times in a consistent position and duration. Record mean, spread, hysteresis and recovery. The goal is channel comparability, not absolute force calibration.

### C. Hall check

Rotate the crank manually for ten revolutions and expect ten events. Resolve double triggers and missed revolutions before calculating cadence.

### D. Haptic localisation

Randomise left and right across ten eyes-closed trials. At least eight correct identifications are required.

### E. Sixty-second personal baseline

The participant pedals naturally at low resistance. The system estimates `baseline_left_share` and cycle-to-cycle variability. It does not impose 50:50 as a medical target.

[CONTENT ID: P3-SESSION-01]

## One complete session

1. Read the non-medical statement and locate stop controls.
2. Inspect the exerciser, magnet, nodes, batteries and cable path.
3. Discover devices and confirm module status.
4. Run unloaded, equal-weight and localisation checks.
5. Record a 60-second natural baseline.
6. Run two-minute training blocks with at least one-minute breaks.
7. Disable cues for an unaided post-test.
8. Record clarity, attention demand, comfort and willingness to stop.
9. Export CSV, session JSON, faults and version metadata.
10. Return for retention and changed-resistance transfer.
11. In E2, select and replay a provenance-labelled past-self trace.

Every start, end, interruption and hardware failure is logged. Missing samples are not interpolated into apparently valid revolutions.

---

[CONTENT ID: P3-C1-01]

## C1 study: four guidance strategies

### V | Visual Feedback

A continuous left–right display and baseline band without bodily vibration. This is the familiar visual comparison.

### CH | Continuous Haptic

Every valid out-of-band revolution generates a side-specific cue. It represents continuous bodily guidance and may create adaptation or dependency.

### FF | Fixed Fade

Cue frequency or probability decreases on a predetermined schedule, regardless of performance. It tests whether simply reducing guidance is sufficient.

### AF | Adaptive Persistent-error Feedback

A cue appears only after three consecutive out-of-band revolutions. Continued deviation increases the pattern from weak to medium to strong; recovery silences it immediately.

A formal study counterbalances condition order. A two-week self-test verifies procedure, logging and comprehensibility; it does not establish effectiveness.

[IMAGE IMG-14] Four columns—V, CH, FF and AF—with Trigger, Body channel, Fade logic, Dependency risk and Primary test as rows. Highlight AF visually without labelling it “best.”

[CAPTION] The conditions separate channel, persistence and fading logic; the decisive comparison occurs after feedback is removed.

[ALT] A four-condition matrix compares visual, continuous haptic, fixed-fade and adaptive persistent-error feedback.

[CONTENT ID: P3-C1-02]

## C1 outcome: what remains without assistance

### Immediate no-feedback post-test

Visual, haptic and target-pointer guidance is removed while contribution remains recorded. This separates “the device is helping me” from “I can maintain it myself.”

### 24-hour retention

The same task returns the next day without assistance. Candidate measures include absolute deviation from the personal target and revolutions required to enter the tolerance band.

### Transfer

Resistance or target cadence changes within the same safe apparatus. The test asks whether the strategy survives a new dynamic condition.

Assistance-on training performance remains secondary. A formal study defines its primary outcome before data collection, preferably an unaided retention or transfer measure.

---

[CONTENT ID: P3-E2-01]

## E2 study: creating a trace of a past self

Select a stable, high-quality 30–60 second segment containing:

- `trace_id` and creation time;
- pseudonymous participant ID;
- contribution and cadence sequences;
- resistance and target;
- device and algorithm versions;
- valid-data and packet-loss rates;
- a transparent selection reason, such as the longest stable segment.

Replay does not simply reproduce old vibration commands. The current state is compared with the historical target and generates a new cue, preserving an active present-task loop.

[CONTENT ID: P3-E2-02]

## Four E2 conditions

### PS-H | Past Self + Haptic

A past-self trajectory is the target; current deviation returns through bilateral haptics.

### MO-H | Matched Other + Haptic

A trajectory from another person is matched on mean, variance, cadence and difficulty, then returned through the same channel. This asks whether identity matters beyond trajectory quality.

### PS-V | Past Self + Visual

The same past-self trajectory appears visually without body-worn haptics, separating provenance from output channel.

### NF | No History

The rider performs the present task without historical guidance.

[IMAGE IMG-15] A 2×2 matrix with Past Self / No Past-self Identity as columns and Haptic / Visual-or-none as rows. Place PS-H, MO-H, PS-V and NF while noting that trajectory quality should be matched.

[CAPTION] E2 separates source identity from embodied delivery rather than comparing history with no history alone.

[ALT] A four-condition matrix compares past-self haptics, matched-other haptics, past-self visual replay and no-history practice.

[CONTENT ID: P3-E2-03]

## Honest labelling in a one-person prototype

Without a second participant, MO-H uses a transformed simulated trace and retains these labels everywhere:

```text
condition = MO-H
trace_source = simulated_matched_other
```

This validates the interaction and protocol, not the psychological distinction between self and other. Presenting simulation as human data would invalidate the capability claim.

---

[CONTENT ID: P3-RULE-01]

## Adaptive feedback rule

```text
IF cycle is invalid:
    no cue
ELSE IF abs(delta) is within personal tolerance:
    stop cue; persistent_error_count = 0
ELSE:
    persistent_error_count += 1
    IF count < 3: no cue
    IF count = 3: weak cue on lower-contribution side
    IF count = 4–5: medium cue
    IF count > 5: strong short cue, then require recovery window
```

The levels are preselected short haptic patterns, not escalating stimulation voltage. A cooldown prevents rapid repeated cues and discomfort.

---

[CONTENT ID: P3-METRIC-01]

## Research measures

**Primary candidates**

- median `abs(left_share - target_share)` during no-feedback testing;
- the same deviation at 24-hour retention;
- transfer loss under changed resistance;
- tracking error relative to a past-self target;
- valid revolutions required to re-enter tolerance.

**Subjective measures**

- clarity of left–right meaning;
- whether guidance supported an independent strategy;
- dependency, distraction or annoyance;
- whether past-self replay felt like personal history or a generic target;
- comfort and desire to stop.

[CONTENT ID: P3-METRIC-02]

## Engineering measures

- packet reception and ten-second packet-loss windows;
- FSR sampling rate and timestamp jitter;
- Hall misses and duplicate events;
- proportion of valid revolutions;
- decision-to-vibration latency;
- disconnect-to-output-off latency;
- eyes-closed localisation accuracy;
- battery runtime, temperature anomalies and resets;
- calibration, mounting and version changes.

Engineering context determines whether behavioural data is interpretable. A change coinciding with packet loss or sensor drift cannot be attributed directly to feedback strategy.

---

[CONTENT ID: P3-DATA-01]

## Data dictionary

```text
t_ms, source, packet_seq, left_raw, right_raw,
left_filtered, right_filtered, cadence_rpm, cycle_id,
cycle_valid, left_area, right_area, left_share,
baseline_share, tolerance_low, tolerance_high, delta,
emg_raw, emg_env, emg_artifact_flag,
cue_side, cue_level, cue_reason, servo_deg,
condition, trace_id, trace_source,
packet_loss, device_version, algorithm_version, mode
```

`source` distinguishes `simulation` from `hardware`. `mode` distinguishes `calibration`, `training`, `no_feedback`, `retention`, `transfer` and `replay`.

[IMAGE IMG-17] Divide one record into Sensing, Cycle Model, Feedback, Condition and Quality. Highlight `cycle_valid`, `packet_loss` and `trace_source` to show that behavioural records retain engineering context.

---

[CONTENT ID: P3-ANALYSIS-01]

## Analysing without overclaiming

A two-week self-test first answers feasibility: does the apparatus remain stable, are cues interpretable, can the protocol run, and can every decision be traced? It does not provide statistical evidence of training benefit.

Suitable portfolio figures include:

- `left_share` over time with the personal baseline band;
- segmented training and no-feedback traces;
- packet-loss and invalid-cycle overlays;
- past-self and present trajectories aligned in time;
- ten repeated calibration points;
- a failed mounting configuration followed by its redesign.

Simulation is labelled “Illustrative simulation.” Real maker data is labelled “Self-test, n=1.” Without a participant study, do not show p-values, confidence intervals or claims of significant improvement.

---

[CONTENT ID: P3-FAIL-01]

## Failure is part of the study apparatus

| State | Detection | System response | Data response |
|---|---|---|---|
| Foot node lost | no packet for 500 ms | stop both haptics; centre pointer | invalidate revolution; log time |
| No Hall event | longer than two expected cycles | suspend revolution calculation | do not create cycle ID |
| Low pressure | integrated load below threshold | no cue | mark idle/unloaded |
| Loss >10% | ten-second window | do not escalate cue | mark radio quality insufficient |
| EMG unavailable | fixed value or absent module | main study continues | empty EMG fields with reason |
| Serial disconnected | read failure | local output off | preserve final timestamp |
| User stop | interface/physical stop | immediately disable output | log reason |

[IMAGE IMG-16] Interface wireframe: device state at top; revolution trace and baseline centrally; condition and cue reason on the right; log, stop and export below. A disconnect produces one clear red state, not multiple overlapping alerts.

[CAPTION] Behaviour and data quality remain visible together, showing both why the machine cues and when it should remain silent.

[ALT] A prototype dashboard displays device health, pressure contribution, cadence, cue reason, study condition, event log and emergency stop.

---

[CONTENT ID: P3-SAFETY-01]

## Human and mechanical safety

- stationary indoor pedalling only; begin at low speed and resistance;
- dual-retained magnet and cable-free crank path;
- off-body LiPo charging; retire damaged, swollen or hot cells;
- insulated enclosures, heat-shrink and strain relief on body-worn nodes;
- short haptic patterns; stop for pain, numbness, dizziness or skin discomfort;
- commercial read-only EMG, preferably battery-powered;
- no use on damaged skin or with implanted electronic devices without professional assessment;
- no DIY EMS/TENS/FES output;
- disconnect, fault and participant stop all silence outputs.

[CONTENT ID: P3-ETHICS-01]

## Boundary between self-test and participant research

A maker self-test checks hardware and protocol; it is not an ethics-approved human study. Before recruiting others, confirm institutional review requirements, consent, exclusion criteria, identifiable bodily-data handling, supervision and stopping procedures.

A formal study also needs counterbalancing, a preregistered primary measure, sample-size justification, recruitment and compensation details, and explicit separation between research risk and ordinary exercise risk.

---

[CONTENT ID: P3-LIMIT-01]

## Limitations

1. Two FSRs are mounting-, footwear- and temperature-sensitive proxies.
2. One Hall event per revolution does not recover continuous crank angle.
3. One EMG channel is vulnerable to crosstalk and motion artefact and cannot represent a whole leg.
4. Vibration is a cue, not force feedback or muscle stimulation.
5. Personalisation does not make a natural baseline medically ideal.
6. A self-test cannot establish population effects.
7. Simulated matched-other data cannot replace a real other person.
8. A compact exerciser differs from real bicycle dynamics.
9. A two-week prototype prioritises integration and protocol over product durability.

The limitations strengthen the case study by making the boundary of every measurement and claim visible.

---

[CONTENT ID: P3-SKILL-01]

## Capabilities enacted through one experiment

| Capability | Action | Evidence |
|---|---|---|
| Literature research | extract mechanisms from Adaptive EMS, MyoAction and bioSync | research map and translated design decisions |
| Body/muscle knowledge | explain cycling timing, EMG artefacts and limits | annotated anatomy and aligned traces |
| Electronics | dividers, ADC, decoupling, grounds and power separation | schematic and multimeter record |
| Embedded systems | sampling, EMA, cycle state machine and fail-safe | firmware, fixtures and logs |
| IoT/wireless | ESP-NOW nodes, sequence, loss and return commands | protocol and disconnect demonstration |
| Mechatronics | Hall, magnet, servo and haptic driver | mounting and physical-state video |
| Fabrication | breadboard, soldering, terminals, heat-shrink and strain relief | build sequence and rework |
| 3D modelling | Hall bracket, dial enclosure and node clips | source CAD, STEP and STL |
| Interaction design | calibration, state, cue semantics and stop controls | storyboard and interface recording |
| Data practice | dictionary, quality fields, traces and export | CSV, figures and version metadata |
| Study design | controls, withdrawal, retention, transfer and provenance | protocol and condition matrix |
| Open-source integration | licences, attribution and adaptation boundaries | third-party register |
| Ethics | self-test boundary, stopping and honest labels | risk sheet and limitations |

[IMAGE IMG-18] An evidence chain from Literature to Hardware, Firmware, Interaction, Data, Study and Reflection. Put a real file or photograph type below each stage rather than a self-rating score.

[CAPTION] Capability is demonstrated through inspectable artefacts, not a self-assessed skills radar.

---

[CONTENT ID: P3-EVIDENCE-01]

## Final evidence package

- research question and related-work map;
- dated BOM with alternatives;
- node schematics and wiring;
- firmware, versions and third-party licences;
- breadboard, soldering, enclosure and mounting photographs;
- calibration, Hall and haptic-localisation results;
- data dictionary, raw CSV, processing and example figures;
- C1/E2 protocols and condition logs;
- CAD source, STEP, STL and tolerance notes;
- fault and emergency-stop recordings;
- 90-second system demonstration;
- failure log and resulting design changes;
- one page stating what was reused, what was changed and what was not claimed.

---

[CONTENT ID: P3-PROTOTYPE-01]

## What the independent interactive prototype should demonstrate

- Simulation and Hardware data sources;
- safety check and device discovery;
- unloaded, equal-weight and 60-second baseline stages;
- pressure, cadence, cycle and optional EMG traces;
- C1 condition selection and guidance fade;
- E2 past-self recording, selection and replay;
- packet loss, Hall failure and node-disconnect simulation;
- cue-reason log and emergency stop;
- CSV/JSON export.

**Public button**  
Open Interactive Prototype ↗

**Prototype status line**  
Simulation is not an experimental result. It explains system rules and rehearses failure states.

---

[CONTENT ID: P3-DEMO-01]

## 90-second supervisor demonstration

**0–10 s | Frame**  
“This is a stationary cycling human–machine–human interface, not a medical device.”

**10–25 s | Input**  
Show bilateral FSRs, Hall sensing and optional EMG entering three ESP32 nodes.

**25–40 s | Interpretation**  
Explain why the system integrates a complete revolution before comparing contribution with a personal baseline.

**40–55 s | Return**  
Intentionally reduce one side. After three revolutions, the corresponding ankle cues and the pointer moves; active correction silences it.

**55–68 s | C1**  
Disable guidance and identify unaided retention and changed-resistance transfer as the meaningful outcomes.

**68–80 s | E2**  
Load a past-self trace and explain PS-H, MO-H, PS-V and NF.

**80–90 s | Evidence**  
Show firmware, wiring, CAD, CSV, protocol, licences and failure log.

---

[CONTENT ID: P3-REFLECT-01]

## Reflection: research making does not require reinventing every layer

The important decision was not to confuse capability with implementing every technology from zero. Existing sensors, radio examples, haptic libraries and repositories allow the two-week effort to focus on the judgement-heavy work: body mapping, cycle modelling, guidance withdrawal, experimental controls, fault handling and evidence.

The claim to a supervisor is not “I have mastered all EMS technology.” It is that I can enter a problem spanning bodies, electronics, code, mechanics and research; find reliable starting points; integrate them safely; build the smallest defensible loop; and identify the supervision and validation required next.

---

[CONTENT ID: P3-NEXT-01]

## Next steps

With supervisor oversight, compliant stimulation hardware and formal safety processes, the platform could extend to:

- compare vibration with commercial force feedback or compliant EMS;
- validate pressure proxies against crank-angle or commercial power measurement;
- use multi-channel EMG for timing across muscles rather than single-channel amplitude;
- recruit real matched-other pairs;
- preregister and power a retention/transfer study;
- study when participants pause, weaken or refuse past-self bodily guidance.

**Closing line**  
The machine becomes useful when it knows how to return the body’s information—and when to step away.

