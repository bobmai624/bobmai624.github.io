# Multilingual Glossary

用途：保持中文、英文、日文在研究与工程术语上的一致性。首次出现时可以同时保留英文缩写。

## 1. 研究与交互

| 中文 | English | 日本語 | 使用说明 |
|---|---|---|---|
| 身体性互动 / 具身交互 | embodied interaction | 身体性インタラクション | 不直译为“身体化互动” |
| 人体增强 | human augmentation | 人間拡張 | 研究领域名 |
| 人到机器再到人 | human → machine → human | 人→機械→人 | 箭头保持一致 |
| 身体化指导 | embodied guidance | 身体的ガイダンス | 指导通过身体输出 |
| 触觉提示 | haptic cue | 触覚提示 | 本项目是提示，不是force feedback |
| 位置对应 | bodily/spatial correspondence | 身体位置対応 | 左信息回左侧 |
| 主体感 | sense of agency | 行為主体感 | 不简化为“control feeling” |
| 运动学习 | motor learning | 運動学習 | 需要保持/迁移，不等于即时表现 |
| 即时表现 | assisted/immediate performance | 補助中の即時パフォーマンス | 与learning分开 |
| 无辅助保持 | unaided retention | 無補助保持 | C1主要结果 |
| 迁移 | transfer | 転移 | 新阻力/新目标 |
| 反馈淡出 | feedback fading | フィードバックのフェードアウト | 固定或自适应 |
| 自适应指导 | adaptive guidance | 適応型ガイダンス | 随错误改变 |
| 持续错误 | persistent error | 継続エラー | 连续多个有效踏圈 |
| 过去自我 | past self | 過去の自己 | E2来源身份 |
| 异步动觉回放 | asynchronous kinesthetic replay | 非同期運動感覚リプレイ | 中性研究术语 |
| 来源信息 | provenance | 出所情報 / プロヴェナンス | 轨迹来自谁、何时、什么版本 |
| 匹配他人 | matched other | マッチした他者 | 真实参与者条件 |
| 模拟匹配他人 | simulated matched other | 模擬matched other | 单人原型必须显式标记 |
| 可证伪 | falsifiable | 反証可能 | 对照可推翻主张 |
| 研究制作 | research through making | Research through Making | 英文术语可保留 |
| 能力证明型原型 | capability-demonstration prototype | 能力実証型プロトタイプ | 不声称产品完成 |

## 2. 身体与生理信号

| 中文 | English | 日本語 | 使用说明 |
|---|---|---|---|
| 肌电图 / 肌电 | electromyography / EMG | 筋電図 / EMG | 本项目为表面肌电 |
| 表面肌电 | surface EMG / sEMG | 表面筋電 / sEMG | 非侵入读取 |
| 只读肌电 | read-only EMG | 読み取り専用EMG | 强调无输出电流 |
| 电刺激 | electrical stimulation | 電気刺激 | 本项目不实施 |
| 电肌肉刺激 | electrical muscle stimulation / EMS | 電気的筋刺激 / EMS | 与EMG严格分开 |
| 功能性电刺激 | functional electrical stimulation / FES | 機能的電気刺激 / FES | 不进入项目 |
| 经皮神经电刺激 | TENS | 経皮的電気神経刺激 / TENS | 不进入项目 |
| 肌电包络 | EMG envelope | EMG包絡線 | 只显示时序/相对活动 |
| 运动伪迹 | motion artefact | 運動アーチファクト | 澳英拼写artefact |
| 串扰 | crosstalk | クロストーク | 邻近肌肉信号 |
| 肌纤维方向 | muscle-fibre direction | 筋線維方向 | 澳英拼写fibre |
| 股外侧肌 | vastus lateralis | 外側広筋 | 说明性EMG目标 |
| 股四头肌 | quadriceps | 大腿四頭筋 | 背景标注 |
| 腘绳肌 | hamstrings | ハムストリングス | 背景标注 |
| 臀大肌 | gluteus maximus | 大殿筋 | 背景标注 |
| 腓肠肌 | gastrocnemius | 腓腹筋 | 背景标注 |
| 胫骨前肌 | tibialis anterior | 前脛骨筋 | 背景标注 |

## 3. 自行车与测量

| 中文 | English | 日本語 | 使用说明 |
|---|---|---|---|
| 固定式脚踏器 | stationary pedal exerciser | 固定式ペダル運動器 | 不是road bike |
| 踏频 | cadence | ケイデンス | 单位RPM |
| 完整踏圈 | complete pedal revolution | ペダル1回転 | 用于算法窗口 |
| 曲柄 | crank | クランク | Hall/magnet安装 |
| 相对压力贡献代理指标 | relative pressure-contribution proxy | 相対的な圧力寄与の代理指標 | 全文固定表达 |
| 左侧贡献比例 | left share / left_share | 左側寄与率 | 数据字段保留英文 |
| 个人自然基线 | personal natural baseline | 個人の自然ベースライン | 非医学标准 |
| 容许区间 | personal tolerance band | 個人許容範囲 | 原型规则 |
| 压力时间积分 | time-integrated pressure | 圧力の時間積分 | 一圈内 |
| 受力扩散片 | force-spreading puck | 荷重拡散板 | 20–30 mm |
| 横向剪切 | lateral shear | 横方向せん断 | FSR风险 |
| 功率 | cycling power | サイクリングパワー | 禁止用FSR声称 |
| 扭矩 | crank torque | クランクトルク | 禁止用FSR声称 |

## 4. 硬件与软件

| 中文 | English | 日本語 | 使用说明 |
|---|---|---|---|
| 力敏电阻 | force-sensitive resistor / FSR | 感圧抵抗 / FSR | 名称可保留FSR |
| 非锁存Hall传感器 | non-latching Hall sensor | 非ラッチ型Hallセンサー | 每圈事件 |
| 触觉驱动器 | haptic motor driver | 触覚モータードライバ | DRV2605L |
| 硬币振动电机 | coin-type vibration motor | コイン型振動モーター | ERM |
| 舵机 | servo motor | サーボモーター | 物理指针 |
| 中央节点 / 中央集线器 | central hub | 中央ハブ | 第三个XIAO |
| 脚部节点 | foot node | 足ノード | 左右两个 |
| 分压电路 | voltage divider | 分圧回路 | 10 kΩ |
| 指数移动平均 | exponential moving average / EMA | 指数移動平均 / EMA | 滤波 |
| 包序号 | packet sequence number | パケット番号 | 丢包 |
| 丢包率 | packet-loss rate | パケット欠損率 | 工程指标 |
| 失联保护 | disconnect fail-safe | 切断フェイルセーフ | 500 ms |
| 数据来源 | data source | データソース | simulation/hardware |
| 设备版本 | device version | デバイスバージョン | 数据字段 |
| 算法版本 | algorithm version | アルゴリズムバージョン | 数据字段 |
| 原始数据 | raw data | 生データ | 不覆盖 |
| 会话日志 | session log | セッションログ | 开始/停止/故障 |

## 5. 实验条件固定写法

| Code | English full name | 中文解释 | 日本語説明 |
|---|---|---|---|
| V | Visual Feedback | 视觉反馈 | 視覚フィードバック |
| CH | Continuous Haptic | 持续触觉提示 | 継続触覚提示 |
| FF | Fixed Fade | 固定淡出 | 固定フェード |
| AF | Adaptive Persistent-error Feedback | 自适应持续错误反馈 | 適応型継続エラーフィードバック |
| PS-H | Past Self + Haptic | 过去自己＋触觉 | 過去自己＋触覚 |
| MO-H | Matched Other + Haptic | 匹配他人＋触觉 | マッチした他者＋触覚 |
| PS-V | Past Self + Visual | 过去自己＋视觉 | 過去自己＋視覚 |
| NF | No History | 无历史轨迹 | 履歴なし |

## 6. 禁止表达及替代

| 不使用 | 原因 | 替代表达 |
|---|---|---|
| corrects muscle imbalance | 医疗/因果过度 | cues persistent deviation from a personal baseline |
| measures cycling power | FSR不能支持 | estimates relative pressure contribution |
| improves muscle memory | 尚无研究结果 | is designed to test unaided retention |
| reads intention from the leg | 单点EMG不足 | records an optional surface-EMG timing signal |
| stimulates the weak leg | 本项目无刺激 | vibrates the corresponding ankle |
| AI detects the correct posture | 无AI且无医学正确值 | rule-based cycle model identifies persistent deviation |
| digital twin of the rider | 数据维度不足 | provenance-labelled past-self trace |
| clinical-grade | 不成立 | research prototype / qualitative sensing |
| safe for everyone | 无法保证 | bounded low-risk prototype with explicit exclusions |
| user study proves | 若只有自测不成立 | self-test demonstrates protocol feasibility |

## 7. 英文风格

- 使用澳大利亚/英式拼写：personalised、behaviour、artefact、fibre；
- 论文原题保持原拼写；
- 少用“revolutionary”“ground-breaking”“seamless”；
- 先写设计判断，再写技术名词；
- `past self`作普通概念，`Past Self + Haptic`作条件名；
- `feedback`作不可数名词，不写`feedbacks`。

## 8. 日文风格

- 页面标题可保留英文类别，正文使用自然日文；
- 第一次出现用「表面筋電（sEMG）」；之后可用sEMG；
- 「補助中の成績」と「学習」を明确分开；
- `past-self`条件名保留英文缩写；
- 避免断言「改善した」「矯正した」，计划用「検証する」「提示する」「記録する」；
- 安全说明不用模糊敬语，采用直接、清楚的陈述。

