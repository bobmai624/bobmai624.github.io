# Content Coverage Matrix

本矩阵供建站工具和最终校验使用。

| 页面 | 中文文件 | 英文文件 | 日文文件 | 核心内容 |
|---|---|---|---|---|
| Page 1 | `01_Chinese/page-1-project-vision.md` | `02_English/page-1-project-vision.md` | `03_Japanese/page-1-project-vision.md` | 问题、闭环、自行车、C1/E2、安全转译 |
| Page 2 | `01_Chinese/page-2-prototype-making.md` | `02_English/page-2-prototype-making.md` | `03_Japanese/page-2-prototype-making.md` | BOM、三节点、安装、开源、14 天制作 |
| Page 3 | `01_Chinese/page-3-experiment-capabilities.md` | `02_English/page-3-experiment-capabilities.md` | `03_Japanese/page-3-experiment-capabilities.md` | 实验、指标、安全、技能、导师演示 |

## 必须一致的数字

| 项目 | 固定值 |
|---|---|
| 页面数 | 3 |
| 语言数 | 3 |
| 必要 ESP32 节点 | 3 |
| 压力传感器 | 2 |
| 触觉输出 | 左右各 1 |
| Hall | 1 工作 + 1 备件 |
| 个人基线 | 60 秒 |
| 提示触发 | 连续 3 个有效踏圈超阈值 |
| 掉线保护 | 500 ms 无新包则关闭输出 |
| 定位预检 | 闭眼 10 次至少正确 8 次 |
| C1 条件 | 4 个训练条件 + 无辅助测试 |
| E2 条件 | PS-H、MO-H、PS-V、NF |
| 制作周期 | 14 天 |
| 主商品历史预算 | AUD 344.65，记录于 2026-08-13，不是实时报价 |

## 词义必须一致

| 正确表达 | 禁止替换为 |
|---|---|
| 相对压力贡献代理指标 | 功率、扭矩、真实肌力 |
| 只读表面肌电 | 电刺激、肌肉驱动 |
| 触觉提示 | 自动纠正身体 |
| 个人自然基线 | 医学正常值、强制 50:50 |
| 可行性自测/原型评估 | 已证明有效的用户研究 |
| 模拟匹配他人轨迹 | 真实他人数据 |
| 固定室内脚踏器 | 道路骑行系统 |

## 内容状态标签

建站时可以在区块角落显示：

- `CONCEPT`：研究概念；
- `PROTOTYPE`：交互或硬件原型；
- `PLANNED STUDY`：尚未完成的实验；
- `BUILD EVIDENCE`：已经有照片/数据支持；
- `OPEN-SOURCE ADAPTATION`：基于第三方项目改编；
- `SAFETY BOUNDARY`：不能省略的边界。

只有在存在相应文件或数据时，才能把 `PLANNED STUDY` 改成 `COMPLETED STUDY`。

