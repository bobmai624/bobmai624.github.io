# Open-source, Tutorials, Product Sources and Citations

核验日期：2026-08-16  
用途：帮助后续开发者正确区分代码许可证、教程引用、产品图片和论文引用。

## 1. 四种来源不能混为一谈

### A. Open-source code

仓库有明确许可证，可以在许可证范围内复制、修改和再发布代码。必须保留相应声明。

### B. Official documentation

可用于学习和引用事实，但文档文字、图片和接线图不自动等于可自由复制。链接原文，自己的作品集尽量重画。

### C. Tutorial reference

可以说明“我按这个教程学习”，但不要复制整段文章、视频截图或未授权代码。

### D. Product/media reference

用于识别产品外观和采购；商品页图片版权通常仍属于商家或厂商。发布优先使用本人实拍。

## 2. 可以直接进入第三方清单的开源项目

### OS-01｜qppd/smart-chair

**链接**：https://github.com/qppd/smart-chair  
**页面显示许可证**：MIT  
**项目提供**：ESP32、FSR、个人tare、EMA、触觉脉冲、串口命令、CSV logger、Fritzing、Fusion 360。  
**PedalBalance Echo 复用**：分压、校准/滤波结构、非阻塞计时、触觉测试、日志格式思路。  
**改写**：座椅静态左右差 → 完整踏圈左右积分；更快的采样窗口；ESP-NOW节点。  
**排除**：坐姿健康声称、flex传感、五FSR布局。

**建议署名**

> Portions of the FSR calibration, filtering and logging architecture were adapted from qppd/smart-chair, used under the MIT License. The cycling task, revolution-based metric and study controller are project-specific adaptations.

### OS-02｜jamesjmtaylor/esp32-ftms-server

**链接**：https://github.com/jamesjmtaylor/esp32-ftms-server  
**页面显示许可证**：MIT  
**项目提供**：固定自行车Hall测速、FTMS、`tachMount.stl`。  
**复用**：Hall事件、去抖/测速和机械支架思路。  
**不进入MVP**：完整BLE FTMS。

**建议署名**

> Hall-sensor cadence and mount references were informed by jamesjmtaylor/esp32-ftms-server, MIT License.

### OS-03｜Adafruit_DRV2605_Library

**链接**：https://github.com/adafruit/Adafruit_DRV2605_Library  
**许可证**：MIT；仓库说明要求再分发时保留原有文字。  
**复用**：I2C初始化、motor library、effect selection。  
**项目新增**：左右位置语义、weak/medium/strong模式、persistent-error controller。

**建议署名**

> Haptic motor control uses the Adafruit DRV2605 Arduino Library by Limor Fried/Adafruit Industries under the MIT License.

### OS-04｜Brillnova/Insole-Pressure-Sensor

**链接**：https://github.com/Brillnova/Insole-Pressure-Sensor  
**许可证**：Creative Commons Attribution-NonCommercial 4.0 International（CC BY-NC 4.0）。仓库明确写明允许非商业署名使用、分享和修改，禁止商业使用。  
**项目提供**：ESP32 + MUX、多点压力、50 ms帧、时间戳、Python热图。  
**MVP使用**：只作未来升级参考，不复制进入核心版本。  
**风险**：如果作品集网站、咨询服务或后续产品构成商业用途，不应在未确认许可的情况下复用其代码或素材。

**建议署名（仅在实际复用时）**

> Multi-sensor insole exploration was adapted from Brillnova/Insole-Pressure-Sensor under CC BY-NC 4.0. No code from this repository is required by the two-FSR MVP.

## 3. 厂商官方代码与文档

### DOC-01｜Seeed XIAO ESP32-C3

**文档**：https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/  
**使用**：尺寸、ADC/I2C/Wi-Fi/BLE、电池管理、pin map、A3/ADC2注意。  
**图片策略**：只作零件识别参考；公开版使用本人实拍或确认Seeed媒体授权。

### DOC-02｜DFRobot SEN0240

**文档**：https://wiki.dfrobot.com/sen0240/  
**已核验事实**：3.3–5.5 V供电、0–3.0 V输出、1.5 V参考、干电极、50 cm电极线、与肌肉方向一致的一般建议。  
**使用**：必须按该型号接线；其他EMG教程只用于概念学习。  
**限制**：官方页面显示内容版权属于DFRobot，图片不自动获得再发布许可。

### DOC-03｜Adafruit DRV2605L Guide

**文档**：https://learn.adafruit.com/adafruit-drv2605-haptic-controller-breakout/overview  
**使用**：I2C、ERM/LRA、效果库、接线和测试。  
**注意**：教程和代码库的版权/许可证可能不同；代码按仓库MIT，教程图按Adafruit内容规则。

### DOC-04｜Espressif ESP-NOW

**文档**：https://docs.espressif.com/projects/arduino-esp32/en/latest/api/espnow.html  
**使用**：peer、send、receive、callback、broadcast examples。  
**项目新增**：节点ID、包序号、压力/故障结构、双向触觉命令。

### DOC-05｜Adafruit FSR Guide

**文档**：https://learn.adafruit.com/force-sensitive-resistor-fsr  
**使用**：分压、FSR行为和原型边界。  
**作品集表达**：qualitative/relative sensing，不引用其图声称本系统已经精确校准。

## 4. 教程和成品演示

这些链接可作为学习路径，但不应标记为开源代码，除非页面另有许可证。

| ID | 链接 | 学什么 | 不复制什么 |
|---|---|---|---|
| TUT-01 | [ESP-NOW Two-Way](https://www.youtube.com/watch?v=qxwXwNS3Avw) | 双向ESP32通信结构 | 视频画面、整段教学文案 |
| TUT-02 | [ESP-NOW Multiple Nodes Dashboard](https://www.youtube.com/watch?v=OLP-HwU36rU) | 多发送器到一个接收器 | 其网站产品结构 |
| TUT-03 | [FSR tutorial](https://www.youtube.com/watch?v=_LuvkEGFas8) | FSR基础接线 | 视频截图 |
| TUT-04 | [Insole making video](https://youtu.be/FMhggBEbbYE) | 多传感鞋垫制作过程 | 未经许可的视频帧 |
| TUT-05 | [DFRobot Clever Rabbit Hat](https://www.dfrobot.com/blog-1129.html) | EMG→舵机完整演示 | 造型和未经确认许可的素材 |
| TUT-06 | [Kyle Husmann stationary bike retrofit](https://www.kylehusmann.com/posts/2025/esp32-stationary-bike/) | Hall、外壳、固件、应用集成 | 文章图片和文字 |
| TUT-07 | [Google Web Serial Codelab](https://codelabs.developers.google.com/web-serial) | 浏览器串口连接和断线 | 把示例当成本项目原创 |
| TUT-08 | [MDN Web Serial](https://developer.mozilla.org/en-US/docs/Web/API/Web_Serial_API) | 支持范围和API概念 | 未说明浏览器限制的宣传 |

## 5. 产品与采购参考

价格和库存属于时间敏感信息。作品集可显示“planning estimate, 13 Aug 2026”，不要抓取实时数字后长期保留。

| 产品 | 识别/采购链接 | 图片发布策略 |
|---|---|---|
| XIAO ESP32-C3 | [Core Electronics](https://core-electronics.com.au/seeed-studio-xiao-esp32c3-tiny-mcu-board-with-wi-fi-and-ble-battery-charge-supported-power-efficiency-and-rich-interface.html) | 本人实拍优先 |
| SEN0240 | [Core Electronics](https://core-electronics.com.au/gravity-analog-emg-sensor-by-oymotion.html) | 本人实拍；厂商图仅参考 |
| DRV2605L | [Core Electronics](https://core-electronics.com.au/adafruit-drv2605l-haptic-motor-controller.html) | 本人实拍；需要时链接Adafruit |
| Interlink 402 | [Little Bird](https://littlebirdelectronics.com.au/products/round-force-sensitive-resistor-fsr-interlink-402) | 本人实拍，保留比例尺 |
| Vibration motor | [Little Bird](https://littlebirdelectronics.com.au/products/mini-vibration-motor-10-2-7mm?collection=dfrobot) | 本人实拍 |
| Hall | [Core Electronics](https://core-electronics.com.au/hall-effect-sensor-ah1815-non-latching.html) | 本人实拍 + 安装图 |
| LiPo | [Core Electronics](https://core-electronics.com.au/polymer-lithium-ion-battery-400mah-38456.html) | 本人实拍，不展示危险改装 |
| 9 g servo | [Jaycar](https://www.jaycar.com.au/arduino-compatible-9g-micro-servo-motor/p/YM2758) | 本人实拍 + 指针成品 |
| Solder kit | [Jaycar](https://www.jaycar.com.au/25w-soldering-iron-starter-kit-with-dmm/p/TS1652) | 制作过程实拍比商品图更有价值 |
| Pedal exerciser | [Kmart Marketplace](https://www.kmart.com.au/product/everfit-pedal-exerciser-mini-exercise-bike-cross-trainer-under-desk-bike-black-110070790/) | 自己装置实拍，不用商品场景图 |

## 6. 研究论文

### PAPER-01｜Adaptive Electrical Muscle Stimulation Improves Muscle Memory

**作者**：Siya Choudhary, Romain Nith, Yun Ho, Jas Brooks, Mithil Guruvugari, Pedro Lopes  
**会议**：CHI 2025  
**链接**：https://lab.plopes.org/published/2025-CHI-AdaptiveEMS.pdf  
**DOI**：https://doi.org/10.1145/3706598.3713676  
**与项目关系**：反馈根据错误从强介入走向较少介入；以无辅助回忆检验学习。  
**重要许可证事实**：论文首页写明 CC BY 4.0。若重画其概念，仍要署名并指出改编。

**引用文案**

> Choudhary, S. et al. (2025). Adaptive Electrical Muscle Stimulation Improves Muscle Memory. CHI ’25. https://doi.org/10.1145/3706598.3713676

### PAPER-02｜My(o) Action

**标题**：My(o) Action: Accelerating Voluntary Actions via Electromyography and Muscle Stimulation  
**会议**：CHI 2026  
**链接**：https://lab.plopes.org/published/2026-CHI-MyoAction.pdf  
**与项目关系**：EMG作为自愿意图的早期身体输入；本项目只复用读取与时序概念，不复现刺激。

### PAPER-03｜bioSync

**标题**：bioSync: A Paired Wearable Device for Blending Kinesthetic Experience  
**会议**：CHI 2017  
**DOI**：https://doi.org/10.1145/3025453.3025829  
**与项目关系**：人→机器→人的跨身体传递；本项目转为过去自己→机器→现在自己。

### PAPER-04｜Safe Electricity-to-body Systems

**标题**：Design Guideline for Developing Safe Systems that Apply Electricity to the Human Body  
**期刊**：TOCHI 2018  
**DOI**：https://doi.org/10.1145/3184743  
**与项目关系**：说明为什么DIY刺激不进入两周原型，以及正式EMS研究需要独立安全工程。

### PAPER-05｜Cycling EMG Review

**标题**：Electromyographic analysis of pedaling: a review  
**作者**：François Hug, Sylvain Dorel  
**期刊**：Journal of Electromyography and Kinesiology, 2009  
**PubMed**：https://pubmed.ncbi.nlm.nih.gov/18093842/  
**DOI**：https://doi.org/10.1016/j.jelekin.2007.10.010  
**与项目关系**：踏圈中的肌肉活动时序、EMG记录/处理与单通道解释限制。

### PAPER-06｜SENIAM

**网站**：https://www.seniam.org/  
**相关页**：

- https://www.seniam.org/fixation.htm
- https://seniam.org/quadricepsfemorisvastuslateralis.html

**与项目关系**：表面EMG的一般定位、方向、固定和外侧广筋参考。作品集人体图必须标记为说明性，而不是临床放置教程。

## 7. 作品集页脚建议

**中文**

> 本项目使用并改编若干开源库和公开教程。完整来源、许可证和修改范围见 Open-source & Citations。产品图片发布优先使用本人实拍；供应商链接用于器材识别与采购记录。

**English**

> This project uses and adapts open-source libraries and public learning resources. Sources, licences and adaptation boundaries are documented in Open-source & Citations. Published component photography should prioritise original photographs; supplier links document identification and procurement.

**日本語**

> 本プロジェクトは複数のオープンソースライブラリと公開教材を参照・改変しています。出典、ライセンス、変更範囲はOpen-source & Citationsに記録しています。部品写真は本人撮影を優先し、販売店リンクは機材識別と調達記録に用います。

## 8. 发布前许可证检查

1. 仓库当前分支是否仍包含同一许可证；
2. 是否复制了代码、模型、数据或图片；
3. 复制范围是否与署名相符；
4. CC BY-NC 内容是否进入商业场景；
5. 是否保留 MIT copyright/license text；
6. 论文图是直接转载还是自己重画；
7. 人物照片是否有发布许可；
8. 商品图是否已换成本人实拍或获得授权；
9. 教程是否被错误标记为开源；
10. 页面是否清楚区分灵感、复现、改编和原创。

