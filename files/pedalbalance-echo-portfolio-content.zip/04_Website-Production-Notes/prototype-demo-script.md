# Interactive Prototype Demo Script

用途：供后续工具制作独立 BodyRelay / PedalBalance Echo 交互原型。本文定义行为和可见文案，不包含程序代码。

## 1. 原型目标

让没有硬件的访客在 3–5 分钟内理解：

1. 为什么必须按完整踏圈计算；
2. 机器什么时候触发左右提示；
3. C1 怎样撤除反馈；
4. E2 怎样保存和重放 past-self；
5. 节点掉线时为什么必须停止输出；
6. 模拟数据与真实数据的边界。

原型不是游戏化成绩面板，也不展示“AI correction score”。

## 2. 全局状态机

```text
WELCOME
→ SAFETY_CHECK
→ SOURCE_SELECT
→ DEVICE_DISCOVERY
→ MODULE_TEST
→ CALIBRATION_ZERO
→ CALIBRATION_EQUAL_WEIGHT
→ HAPTIC_LOCALISATION
→ BASELINE_60S
→ CONDITION_SELECT
→ TRAINING
→ NO_FEEDBACK
→ RETENTION_OR_TRANSFER
→ TRACE_RECORD
→ TRACE_REPLAY
→ EXPORT

ANY STATE → STOP_OUTPUT → SAFE_IDLE
ANY HARDWARE FAULT → FAULT → SAFE_IDLE
```

## 3. 全局界面区域

### A. Mode

- `Simulation`：内置可控数据；
- `Hardware`：Web Serial 或其他真实数据输入；
- 当前 mode 始终显示，不允许隐藏。

### B. Device health

- Left Node；
- Right Node；
- Hub；
- Hall；
- Optional EMG。

每个状态只能是：`Ready / Missing / Unstable / Not used`。

### C. Main view

- 当前完整踏圈；
- `left_share`；
- 个人 baseline band；
- cue side / level / reason；
- condition；
- cycle validity。

### D. Persistent controls

- Stop Output；
- Pause Session；
- Save Note；
- Export；
- Language。

## 4. Scene 01｜Welcome

**目的**：在操作前确立研究与安全边界。

**中文**

- 标题：把身体动作传给机器，再把信息交还身体
- 正文：这个模拟器解释 PedalBalance Echo 的运行逻辑。它不是实验结果，也不是医疗工具。
- 主按钮：开始系统导览
- 次按钮：直接进入实验条件
- 状态：Illustrative Simulation

**English**

- Title: Return bodily movement through a machine
- Body: This simulator explains the logic of PedalBalance Echo. It is not an experimental result or a medical tool.
- Primary: Start System Walkthrough
- Secondary: Explore Study Conditions
- Status: Illustrative Simulation

**日本語**

- タイトル：身体の動きを機械に渡し、もう一度身体へ返す
- 本文：このシミュレーターはPedalBalance Echoの動作原理を説明するものであり、実験結果や医療ツールではありません。
- 主ボタン：システムを見る
- 副ボタン：実験条件を見る
- 状態：Illustrative Simulation

## 5. Scene 02｜Safety Check

访客需要勾选或逐项阅读：

1. Stationary indoor use only；
2. No DIY electrical stimulation；
3. EMG is read-only and optional；
4. Stop output on discomfort or fault；
5. FSR values are relative proxies。

按钮三语：

- 中文：我理解这些边界 / 返回
- English: I Understand These Boundaries / Back
- 日本語：安全範囲を確認しました / 戻る

如果未确认，Simulation 仍可查看，但 Hardware 入口保持禁用并说明原因。

## 6. Scene 03｜Source Select

**Simulation**

- 滑杆：Left pressure、Right pressure、Cadence、Packet loss；
- 开关：Optional EMG、Hall fault；
- 数据标记：`source = simulation`。

**Hardware**

- 按钮：Connect Hardware；
- 状态：Waiting for serial device；
- 断开：Hardware disconnected—outputs have been silenced。

三语按钮：

| ID | 中文 | English | 日本語 |
|---|---|---|---|
| UI-SOURCE-01 | 模拟模式 | Simulation | シミュレーション |
| UI-SOURCE-02 | 硬件模式 | Hardware | 実機 |
| UI-SOURCE-03 | 连接硬件 | Connect Hardware | 実機に接続 |
| UI-SOURCE-04 | 断开连接 | Disconnect | 接続を解除 |

## 7. Scene 04｜Device Discovery

显示五行设备状态。Simulation 中允许点击 `Simulate Missing Node`。

**正常日志**

```text
[00:00.000] Hub ready
[00:00.148] Left node registered
[00:00.212] Right node registered
[00:00.486] Hall idle—waiting for revolution
[00:00.500] EMG not used—main study available
```

**失败逻辑**

- 左/右节点 Missing：不能进入训练；
- Hall Missing：允许传感器图，但不计算 cycle；
- EMG Missing：允许完整主实验；
- Hub Missing：所有模块锁定。

## 8. Scene 05｜Module Test

按顺序完成：

1. Press Left FSR；
2. Press Right FSR；
3. Pass Magnet Across Hall；
4. Test Left Haptic；
5. Test Right Haptic；
6. Centre Servo Pointer；
7. Optional EMG Rest / Gentle Contraction。

每一项显示 `Not tested / Pass / Unstable / Skip optional`。

## 9. Scene 06｜Zero-load Calibration

**画面**：10秒倒计时、左右原始值、噪声带。

**通过条件文案**

- 中文：两个通道均未饱和，零载噪声已记录。
- English: Both channels are unsaturated and unloaded noise has been recorded.
- 日本語：両チャンネルは飽和しておらず、無負荷ノイズを記録しました。

**失败**：值不变化、顶格、底格、跳变。按钮 `Repeat Zero Check`。

## 10. Scene 07｜Equal-weight Calibration

分为 Left ×10 和 Right ×10。每次放置同一重量，访客点击 `Record`。模拟模式自动生成带小量噪声的重复点。

必须显示：mean、spread、drift、channel ratio。不得显示牛顿或千克的“传感器测量值”；已知重量只用于重复加载。

## 11. Scene 08｜Haptic Localisation

随机左右十次；访客选择感受到哪一侧。模拟网站可通过屏幕左右闪动代替真实振动，但必须标记 `Visual stand-in for haptic localisation`。

通过：8/10。  
未通过：提示改变身体位置，而不是增加到“危险强度”。

## 12. Scene 09｜60-second Baseline

显示：

- valid cycles；
- current left_share；
- evolving baseline mean；
- tolerance band；
- cadence；
- packet loss。

基线期间 `cue_side = none`。结束后显示：

> This is a personal reference for the prototype—not a clinical target and not an enforced 50:50 split.

## 13. Scene 10｜Complete-revolution Explainer

这是原型最重要的教学场景。

### Instantaneous view

左右曲线交替，界面产生多个假警报。标记：`Incorrect comparison for cyclical movement`。

### Full-revolution view

Hall关闭一个区间，面积填充，计算 `left_share`。标记：`Prototype comparison used by PedalBalance Echo`。

访客拖动一整圈时间轴，观察结果只在 Hall 事件后更新。

## 14. Scene 11｜C1 Condition Select

四个条件卡：V、CH、FF、AF。每个卡片显示 Channel、Trigger、Fade、Primary test。

按钮：

- 中文：使用此条件开始 / 查看无反馈测试
- English: Run This Condition / View No-feedback Test
- 日本語：この条件を開始 / 無提示テストを見る

AF 不显示“推荐”或“最佳”。

## 15. Scene 12｜Training

画面每个 Hall 事件增加一个 cycle。访客可拖动左右贡献或点击 `Introduce persistent deviation`。

AF 日志示例：

```text
Cycle 18 valid: delta +0.043, no cue (1/3)
Cycle 19 valid: delta +0.047, no cue (2/3)
Cycle 20 valid: delta +0.051, LEFT cue weak (3/3 persistent)
Cycle 21 valid: back within tolerance, cue stopped
```

需要显示“为什么没提示”，不能只记录提示发生。

## 16. Scene 13｜No-feedback

所有 cue 和目标视觉隐藏，仍记录传感器和完整踏圈。

屏幕固定提示：

- 中文：反馈已关闭。这里观察的是独立表现，而不是提示下的成绩。
- English: Guidance is off. This phase observes independent performance, not assisted performance.
- 日本語：ガイダンスを停止しました。補助中ではなく、自立したパフォーマンスを記録します。

## 17. Scene 14｜Retention / Transfer

访客选择：

- Same resistance / 24h retention；
- Changed resistance；
- Changed target cadence。

模拟器将任务标为 `illustrative protocol preview`，不虚构24小时已经过去。可以加载示例文件，但清楚写 `example dataset`。

## 18. Scene 15｜Record Past-self Trace

选择连续30–60秒区间。显示选择理由字段：

- Longest stable valid segment；
- Lowest packet loss；
- Manually selected with note。

生成：`trace_id`、created_at、source、condition、device_version、validity。

按钮：

- 中文：保存为过去自我轨迹
- English: Save as Past-self Trace
- 日本語：過去自己の軌跡として保存

## 19. Scene 16｜E2 Condition Select

四卡：PS-H、MO-H、PS-V、NF。

单人模式选择MO-H时，强制出现：

> No second participant is available. This condition uses `simulated_matched_other` and cannot test real self–other identity effects.

访客必须确认后才能继续。

## 20. Scene 17｜Replay

顶部显示 `Current body` 与 `Trace source`。触觉命令根据当前差异重新生成，不播放旧 motor event。

日志：

```text
trace_id = PS_20260816_A
trace_source = past_self
current_cycle = 44
target_left_share = 0.486
current_left_share = 0.531
cue_side = right
cue_reason = current-to-trace deviation
```

## 21. Scene 18｜Fault Simulation

四个按钮：

- Drop Left Node；
- Stop Hall Events；
- Raise Packet Loss；
- Disconnect Serial。

预期：

- 500 ms后触觉关闭；
- 舵机回中；
- 当前圈无效；
- 曲线停止，不继续伪造数据；
- 故障被写入日志；
- EMG故障不阻止主实验。

## 22. Scene 19｜Stop Output

`Stop Output` 始终可见。触发后：

1. haptic off；
2. servo centre；
3. session paused；
4. reason requested but optional；
5. data saved until stop timestamp。

按钮三语：

- 中文：立即关闭输出
- English: Stop All Output
- 日本語：すべての出力を停止

## 23. Scene 20｜Export

导出内容：

- Raw CSV；
- Session JSON；
- Trace JSON；
- Calibration summary；
- Fault log；
- Version manifest；
- Human-readable session summary。

下载前显示：

> Check that simulation, self-test and participant data are labelled correctly before publication.

## 24. 演示模式

提供一个不超过90秒的自动导览，但每一步可以暂停：

```text
0–10s  Safety and project frame
10–25s Inputs and full-revolution model
25–45s Persistent deviation and side cue
45–55s Active recovery and cue stop
55–68s No-feedback C1 phase
68–82s Past-self E2 replay
82–90s Fault stop and evidence export
```

自动导览不自动滚动整页，而是在同一主视图中逐步改变状态。

## 25. 原型验收

- 无硬件可走完20个场景；
- Hardware模式断线立即进入安全状态；
- 所有状态有中文、英文、日文文字；
- Simulation标记始终可见；
- C1与E2条件都可到达；
- MO-H模拟来源不能被隐藏；
- 完整踏圈解释可交互；
- `Stop All Output` 始终可用；
- 可导出示例数据；
- 不出现医疗结论、功率值或EMS刺激控制。

