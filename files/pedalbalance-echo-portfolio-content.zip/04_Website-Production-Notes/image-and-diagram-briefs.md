# Image and Diagram Briefs

用途：定义作品集需要的18张核心图。此文件不包含图片；它提供构图、标注、来源策略和发布边界。

## 全局图片原则

1. 商品页和厂商文档图片仅作为识别零件的参考，不自动视为可公开转载。
2. 项目完成后，所有商品图优先换成本人实拍。
3. 系统图、接线图、流程图和人体图应自行绘制，并保留源文件。
4. 论文图优先重画概念并写 `Adapted from …`，不要直接截论文页面。
5. 解剖图必须写“illustrative / not for clinical placement”。
6. 模拟界面和数据图必须写 `Illustrative simulation`。
7. 每张图片文件名建议使用 `img-01-human-machine-human-hero` 这种稳定格式。

---

## IMG-01｜Human–Machine–Human Hero

**页面**：Page 1 Hero  
**类型**：原创场景图或完成后的实拍+信息叠加  
**宽高建议**：4:3 或 5:4

**画面**

- 稳定坐姿的人使用固定式小型脚踏器；
- 脚部节点不夸张，能看见左右踝带；
- 中央舵机指针固定在脚踏器前；
- 电脑显示简洁曲线，不显示虚构“成功率”；
- 三组箭头：Body input、Machine interpretation、Body return。

**标注**

1. Left/right relative pressure；
2. Hall revolution event；
3. Optional read-only sEMG；
4. ESP-NOW hub；
5. Physical pointer；
6. Side-specific ankle vibration。

**禁止**

- 不画道路骑行；
- 不画刺激电极闪电符号；
- 不把肌肉画成被机器强制牵引；
- 不显示医疗诊断值。

**制作策略**：项目未完成前可用干净的原创插画；完成后换成本人实拍并保留透明注释层。

---

## IMG-02｜Human → Machine → Human System Loop

**页面**：Page 1  
**类型**：原创矢量信息图  
**宽高建议**：1:1

**节点**

1. Body Signals；
2. Sensing；
3. Cycle Model；
4. Haptic / Mechanical Feedback；
5. Active Correction；
6. Retention & Replay。

**中心文字**：PedalBalance Echo  
**外围副线**：Past trace 从 Retention 回到 Cycle Model。  
**视觉编码**：实线表示实时闭环，虚线表示跨时间回放。

**核心图注**：机器有价值的时刻，不只是它返回信息时，也包括它知道何时退出时。

---

## IMG-03｜Six-step Use Scenario

**页面**：Page 1  
**类型**：六格故事板  
**画面顺序**：Safety → Baseline → Persistent deviation → Haptic cue → Active correction → No-feedback test。

**每格必须显示**

- 简化的左右踏圈图；
- 当前机器状态；
- 是否振动；
- 使用者动作；
- `valid cycle` 或 `no cue` 的理由。

**不要显示**：一个瞬时压力样本直接触发。

---

## IMG-04｜C1/E2 Research Space

**页面**：Page 1  
**类型**：二维研究框架

**横轴**：Guidance Source：External System → Past Self  
**纵轴**：Output Channel：Visual → Embodied  
**C1区域**：feedback strategy / fading / retention  
**E2区域**：provenance / past-self identity / replay

**注释**

- Performance ≠ Learning；
- Past trace ≠ Past-self effect；
- 两区域重叠处写 `Embodied guidance that eventually withdraws`。

---

## IMG-05｜Main Parts Flat Lay

**页面**：Page 2 Hero  
**类型**：本人实拍优先

**分组**

- Compute：3× XIAO；
- Sense：2× FSR、Hall、optional SEN0240；
- Return：2× DRV2605L、3× vibration motor、servo；
- Power & Build：LiPo、wire、foam、straps；
- Platform：pedal exerciser。

**拍摄**

- 柔和顶光；
- 中性无纹理背景；
- 不拆除产品标签但不突出商标；
- 保留一张无标注原图和一张标注版；
- 图片旁写拍摄日期和 prototype revision。

**供应商参考**

- [XIAO ESP32-C3](https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/)
- [Interlink 402](https://littlebirdelectronics.com.au/products/round-force-sensitive-resistor-fsr-interlink-402)
- [DRV2605L](https://learn.adafruit.com/adafruit-drv2605-haptic-controller-breakout/overview)
- [SEN0240](https://wiki.dfrobot.com/sen0240/)

---

## IMG-06｜Three-node Architecture

**页面**：Page 2  
**类型**：原创系统图

**节点内容**

- Left node：FSR / DRV2605L / motor / LiPo / optional EMG；
- Right node：FSR / DRV2605L / motor / LiPo；
- Hub：ESP-NOW / Hall / cycle model / servo / USB。

**边标签**

- FSR → ADC；
- EMG → ADC1；
- Motor ← I2C driver；
- Foot ↔ Hub：ESP-NOW；
- Hub → PC：USB Serial；
- Hub → Servo：PWM。

**故障副图**：一侧节点用虚线断开，旁边写 `500 ms timeout → all haptics off`。

---

## IMG-07｜FSR Pedal Cross-section

**页面**：Page 2  
**类型**：原创剖面/爆炸图

**层级从上到下**

1. Shoe sole；
2. Soft pedal cover；
3. 20–30 mm force-spreading puck；
4. FSR sensing circle；
5. 2–5 mm EVA；
6. Pedal body。

**侧面**：FSR tail → socket/terminal → strain relief。  
**错误示例**：sharp object、folded tail、direct solder、unprotected shear。  
**公开警告**：Mounting affects the measurement.

---

## IMG-08｜Annotated Body and Bicycle Installation

**页面**：Page 2  
**类型**：人体+脚踏器侧视/斜视原创图

**标注位置**

- FSR：左右踏板软层内；
- Foot node：脚踝绑带上方或鞋面外侧，不进入曲柄；
- Vibration motor：左右外踝附近的软带上；
- Optional EMG：说明性目标肌肉区域；
- Hall：固定车架；
- Magnet：旋转件；
- Hub/servo：脚踏器前方静止部件；
- USB/power：向后离开曲柄。

**红色禁区**：曲柄旋转弧、松散线材、磁铁飞脱方向。  
**注释**：Stationary use only / Low resistance first / No road riding。

---

## IMG-09｜Cycling Muscles and Optional Read-only EMG

**页面**：Page 2  
**类型**：原创简化解剖说明图

**必须标出**

- Vastus lateralis；
- Rectus femoris / quadriceps group；
- Hamstrings；
- Gluteus maximus；
- Gastrocnemius；
- Tibialis anterior。

**高亮**：vastus lateralis 上方一个说明性干电极板轮廓。  
**文字**：

- `Illustrative read-only sEMG channel`；
- `Align with muscle-fibre direction`；
- `Not total leg force`；
- `Not a clinical placement guide`。

**来源依据**

- [Cycling EMG review](https://pubmed.ncbi.nlm.nih.gov/18093842/)
- [SENIAM placement](https://www.seniam.org/fixation.htm)
- [SENIAM vastus lateralis](https://seniam.org/quadricepsfemorisvastuslateralis.html)

**禁止**：不要画刺激电流、收缩闪电或治疗效果。

---

## IMG-10｜Hall, Magnet and Servo Mechanical Detail

**页面**：Page 2  
**类型**：两个局部工程图

**A：Hall**

- 固定支架；
- 非接触间隙；
- 磁铁机械固定 + 第二保险；
- 传感线固定；
- 旋转禁区。

**B：Servo dial**

- 5 V独立供电；
- common ground；
- baseline center；
- software angle limit；
- cardboard v1 → printed v2。

---

## IMG-11｜Open-source Reuse Map

**页面**：Page 2  
**类型**：来源—模块映射图

**六个来源**

1. Smart Chair；
2. Espressif ESP-NOW；
3. ESP32 FTMS server；
4. Adafruit DRV2605 library；
5. Insole Pressure Sensor；
6. DFRobot SEN0240 examples。

每个来源显示三列：`Reuse` / `Adapt` / `Exclude`。  
许可证直接放来源名旁：MIT、CC BY-NC 4.0、Official documentation、Tutorial reference。

**禁止**：只摆Logo，不解释技术流入关系。

---

## IMG-12｜14-day Build Timeline

**页面**：Page 2  
**类型**：泳道时间线

**泳道**：Sense / Connect / Compute / Return / Study / Document  
**天数**：D1–D14  
**每个节点**：任务 + 可见证据 + gate。

**关键Gate**

- D2：同重量重复；
- D4：500 ms fail-safe；
- D5：one event/revolution；
- D7：8/10 localisation；
- D9：simulation/hardware共用界面；
- D14：离线演示包。

---

## IMG-13｜Study Journey

**页面**：Page 3 Hero  
**类型**：实验流程图

**步骤**：Safety → Device Check → Calibration → 60s Baseline → Training → No-feedback → 24h Retention → Transfer → Replay → Export。

Training 下方分出 C1，Replay 下方分出 E2。  
所有输出箭头最终进入 `Raw data + quality flags + version`。

---

## IMG-14｜C1 Condition Matrix

**页面**：Page 3  
**类型**：四列矩阵

| 行 | V | CH | FF | AF |
|---|---|---|---|---|
| Channel | visual | haptic | haptic | haptic |
| Trigger | continuous display | each out-of-band cycle | time schedule | 3 persistent cycles |
| Fade | none | none | fixed | performance-linked |
| Main risk | visual attention | dependency/adaptation | mistimed withdrawal | rule complexity |
| Main test | no-feedback | no-feedback | retention | retention + transfer |

**视觉要求**：所有列同权重；AF可强调但不能写“winner”。

---

## IMG-15｜E2 Condition Matrix

**页面**：Page 3  
**类型**：2×2 + 条件说明

**四格**：PS-H、MO-H、PS-V、NF。  
**额外标签**：MO-H 在单人版本中写 `simulated_matched_other`。  
**底部文字**：Match mean, variance, cadence and difficulty before interpreting identity.

---

## IMG-16｜Interactive Prototype Wireframe

**页面**：Page 3  
**类型**：桌面和移动端线框图

**桌面区域**

1. Mode：Simulation / Hardware；
2. Device health；
3. Pressure contribution + baseline band；
4. Cadence / cycle validity；
5. C1/E2 condition；
6. Cue side, level and reason；
7. Event log；
8. Stop output；
9. Export。

**移动端**：状态 → 主曲线 → 当前提示 → 控制 → 日志。  
**故障示例**：Right node lost；曲线冻结而不是继续生成假数据。

---

## IMG-17｜Data Record Anatomy

**页面**：Page 3  
**类型**：数据字段分解图

**组别**

- Sensing：raw/filtered/cadence；
- Cycle Model：cycle_id/valid/areas/share；
- Feedback：side/level/reason/servo；
- Study：condition/trace/mode；
- Quality：loss/version/source。

**高亮**：`cycle_valid`、`trace_source`、`packet_loss`、`source`。  
**主句**：Behavioural data is only interpretable with engineering context.

---

## IMG-18｜Capability Evidence Chain

**页面**：Page 3  
**类型**：证据链，不是技能雷达

**阶段与证据**

- Literature → annotated paper map；
- Electronics → schematic + multimeter；
- Firmware → repository + test log；
- Fabrication → soldering + enclosure；
- Interaction → prototype recording；
- Data → raw CSV + dictionary；
- Study → protocol + condition log；
- Reflection → failure/change record。

**禁止**：百分比技能分数、空泛“熟练掌握”图标。

## 图片拍摄清单

硬件到货后至少拍：

1. 未拆封/型号核对；
2. 全部零件俯拍；
3. XIAO尺寸；
4. FSR与端子；
5. 单片FSR面包板；
6. 左右节点并排；
7. DRV2605L与振动器；
8. Hall手持磁铁测试；
9. Hall上车；
10. 舵机纸板表盘；
11. 踏板分层装配；
12. 踝带正面/侧面；
13. EMG静态测试；
14. 焊接过程；
15. 热缩和拉力缓解；
16. 失败装法；
17. 修改后装法；
18. 整体装置；
19. 参与者视角；
20. 最终导师演示。

每次拍摄保留：无标注原图、标注副本、日期、硬件revision、拍摄者和是否获得人物发布许可。

