# Trilingual Captions, Alt Text and UI Labels

用途：网站语言切换时同步更新图片图注、alt text、按钮、状态与图中标注。

## 1. 图片图注与Alt Text

### IMG-01

**中文图注**：人的踩踏动作被传感器读取、由机器按完整踏圈解释，再以视觉、机械和触觉形式返回身体。  
**English caption**: Pedalling is sensed, interpreted across complete revolutions, and returned through visual, physical and tactile channels.  
**日本語キャプション**：ペダリングを取得し、1回転単位で解釈し、視覚・物理・触覚の経路から身体へ返す。

**中文Alt**：一名使用固定脚踏器的参与者，左右压力、踏频和可选肌电进入中央系统，左右踝部接收振动提示。  
**English Alt**: A participant uses a stationary pedal exerciser while left–right pressure, cadence and optional EMG feed a central system that returns ankle vibration.  
**日本語Alt**：固定式ペダルを使う人の左右圧力、ケイデンス、任意EMGが中央システムへ入り、足首の振動として戻る。

### IMG-02

**中文图注**：闭环的终点不是更强的机器控制，而是机器退出后仍能留下可观察的身体策略。  
**English caption**: The loop aims not for stronger machine control, but for a bodily strategy that remains when the machine withdraws.  
**日本語キャプション**：目標は機械制御を強めることではなく、機械が退いた後にも身体戦略が残ることである。

**中文Alt**：身体信号经过传感、完整踏圈计算和触觉反馈，进入主动修正、保持与过去轨迹重放。  
**English Alt**: Bodily signals move through sensing, full-revolution modelling and feedback into active correction, retention and replay.  
**日本語Alt**：身体信号がセンシング、1回転モデル、フィードバックを経て、能動修正、保持、再生へ進む。

### IMG-03

**中文图注**：系统不纠正每一个瞬时差异；只有完整踏圈中的偏差持续出现，身体提示才启动。  
**English caption**: The system ignores momentary alternation and cues only when deviation persists across complete revolutions.  
**日本語キャプション**：瞬間的な左右交替には反応せず、複数回転にわたりずれが続いた場合だけ提示する。

**中文Alt**：六阶段示意图显示安全、基线、持续偏差、对应侧振动、主动恢复和无反馈测试。  
**English Alt**: Six stages show safety, baseline, persistent deviation, side-specific vibration, active recovery and no-feedback testing.  
**日本語Alt**：安全、ベースライン、継続ずれ、片側振動、能動回復、無提示テストの六段階。

### IMG-04

**中文图注**：C1 研究机器何时退出；E2 研究身体化指导来自谁。  
**English caption**: C1 asks when the machine should withdraw; E2 asks whose embodied guidance is returned.  
**日本語キャプション**：C1は機械がいつ退くかを問い、E2は誰の身体的ガイダンスが返されるかを問う。

**中文Alt**：研究空间图将外部与过去自己、视觉与身体输出分开，并标出 C1 和 E2。  
**English Alt**: A research-space map separates external and past-self guidance from visual and embodied output, locating C1 and E2.  
**日本語Alt**：外部と過去自己、視覚と身体出力を分け、C1とE2を配置した研究マップ。

### IMG-05

**中文图注**：压力和踏圈进入机器，触觉和机械运动返回身体。  
**English caption**: Pressure and revolution events enter the machine; tactile and mechanical states return to the rider.  
**日本語キャプション**：圧力と回転イベントを機械へ取り込み、触覚と物理状態を身体へ返す。

**中文Alt**：主要电子零件按照传感、计算、反馈、电源和平台分组摆放。  
**English Alt**: The main components are grouped as sensing, computation, feedback, power and platform.  
**日本語Alt**：主要部品をセンシング、計算、フィードバック、電源、プラットフォームに分けた写真。

### IMG-06

**中文图注**：三节点边界让压力、无线、踏圈、触觉和界面可以分别测试。  
**English caption**: Three-node boundaries allow pressure, radio, revolutions, haptics and interface logic to be tested independently.  
**日本語キャプション**：三ノードの境界により、圧力、無線、回転、触覚、画面を独立して検証できる。

**中文Alt**：左右脚节点通过 ESP-NOW 连接中央节点，中央节点连接 Hall、舵机和电脑。  
**English Alt**: Left and right foot nodes connect through ESP-NOW to a hub attached to Hall sensing, a servo and the computer.  
**日本語Alt**：左右足ノードがESP-NOWで中央ハブへ接続し、Hall、サーボ、PCへつながる。

### IMG-07

**中文图注**：FSR 需要受力扩散和防剪切结构；安装方式本身会改变测量。  
**English caption**: FSR mounting requires force spreading and shear protection; the installation changes the measurement.  
**日本語キャプション**：FSRには荷重拡散とせん断保護が必要で、装着方法自体が計測を変える。

**中文Alt**：踏板剖面显示鞋底、软覆盖、扩散片、FSR、EVA、踏板和受保护的传感器尾部。  
**English Alt**: An exploded pedal section shows shoe, cover, force spreader, FSR, EVA, pedal and protected sensor tail.  
**日本語Alt**：靴、カバー、荷重拡散板、FSR、EVA、ペダル、保護テールの分解図。

### IMG-08

**中文图注**：所有传感器、节点和线缆都位于固定设备的可控区域，并避开曲柄运动路径。  
**English caption**: Sensors, nodes and cables remain within a controlled stationary setup and outside the crank path.  
**日本語キャプション**：センサー、ノード、配線を固定環境内に置き、クランク可動範囲を避ける。

**中文Alt**：身体和固定脚踏器标注图显示 FSR、踝部振动、可选 EMG、Hall、磁铁、中央节点与运动禁区。  
**English Alt**: An annotated rider and pedal exerciser show FSRs, ankle haptics, optional EMG, Hall, magnet, hub and moving exclusion zone.  
**日本語Alt**：FSR、足首触覚、任意EMG、Hall、磁石、ハブ、可動禁止領域を示す装着図。

### IMG-09

**中文图注**：单通道表面肌电可以展示活动时序，但不能代表整条腿的机械贡献。  
**English caption**: A single surface-EMG channel can illustrate timing, but not the mechanical contribution of an entire leg.  
**日本語キャプション**：1チャンネルsEMGは活動タイミングを示せるが、脚全体の機械的寄与は表さない。

**中文Alt**：下肢肌肉图突出股外侧肌的说明性只读肌电区域，并写明不是整腿力量。  
**English Alt**: A lateral-leg anatomy diagram highlights an illustrative read-only channel over the vastus lateralis and states that it is not total leg force.  
**日本語Alt**：外側広筋上の読み取り専用EMGを強調し、脚全体の力ではないと示す下肢筋図。

### IMG-10

**中文图注**：Hall 和磁铁使用非接触、双保险安装；舵机独立供电并限制角度。  
**English caption**: Hall and magnet use non-contact, dual-retained mounting; the servo is independently powered and angle-limited.  
**日本語キャプション**：Hallと磁石は非接触・二重保持、サーボは独立給電と角度制限を用いる。

**中文Alt**：Hall、磁铁、曲柄禁区和独立供电舵机的机械安装细节。  
**English Alt**: Mechanical details show the Hall gap, retained magnet, crank exclusion zone and separately powered servo.  
**日本語Alt**：Hall間隔、磁石保持、クランク禁区、独立給電サーボの詳細図。

### IMG-11

**中文图注**：快速完成依靠明确的复用、改写与排除，而不是复制整个项目。  
**English caption**: Fast completion comes from explicit reuse, adaptation and exclusion—not copying an entire project.  
**日本語キャプション**：迅速な制作は、プロジェクト全体のコピーではなく、再利用・変更・除外の明確化から生まれる。

**中文Alt**：六个代码和教程来源分别连接到 FSR、无线、Hall、触觉、EMG 和未来鞋垫模块。  
**English Alt**: Six code and tutorial sources map to FSR, radio, Hall, haptics, EMG and future insole modules.  
**日本語Alt**：六つのコード/教材をFSR、無線、Hall、触覚、EMG、将来インソールへ対応させた図。

### IMG-12

**中文图注**：14 天计划让每一天都留下可以检查的制作证据。  
**English caption**: The 14-day plan leaves an inspectable build artefact every day.  
**日本語キャプション**：14日計画では、毎日確認できる制作証拠を残す。

**中文Alt**：Sense、Connect、Compute、Return、Study、Document 六条泳道组成的十四天时间线。  
**English Alt**: A fourteen-day timeline across Sense, Connect, Compute, Return, Study and Document swimlanes.  
**日本語Alt**：Sense、Connect、Compute、Return、Study、Documentの六レーンによる14日時間線。

### IMG-13

**中文图注**：训练只是流程的一部分；无辅助后测、迁移和来源对照决定系统能回答什么。  
**English caption**: Training is only one stage; unaided tests, transfer and provenance controls determine what the system can answer.  
**日本語キャプション**：トレーニングは一段階であり、無補助、転移、出所対照が研究の範囲を決める。

**中文Alt**：安全、校准、基线、训练、无反馈、保持、迁移、重放和导出的实验流程。  
**English Alt**: A study flow covers safety, calibration, baseline, training, no-feedback, retention, transfer, replay and export.  
**日本語Alt**：安全、校正、ベースライン、トレーニング、無提示、保持、転移、再生、出力の流れ。

### IMG-14

**中文图注**：四个 C1 条件分离反馈通道、持续性和淡出逻辑。  
**English caption**: Four C1 conditions separate feedback channel, persistence and fading logic.  
**日本語キャプション**：四つのC1条件で提示経路、継続性、フェードロジックを分ける。

**中文Alt**：视觉、连续触觉、固定淡出和自适应持续错误反馈的四列矩阵。  
**English Alt**: A four-column matrix compares visual, continuous haptic, fixed-fade and adaptive persistent-error feedback.  
**日本語Alt**：視覚、継続触覚、固定フェード、適応型継続エラー提示の四列比較。

### IMG-15

**中文图注**：E2 同时拆开过去自我身份与身体输出通道。  
**English caption**: E2 separates past-self identity from the embodied delivery channel.  
**日本語キャプション**：E2では過去自己の出所と身体的提示経路を分ける。

**中文Alt**：PS-H、MO-H、PS-V 和 NF 的二维条件矩阵。  
**English Alt**: A two-dimensional condition matrix shows PS-H, MO-H, PS-V and NF.  
**日本語Alt**：PS-H、MO-H、PS-V、NFを配置した二次元条件マトリクス。

### IMG-16

**中文图注**：原型同时显示行为和数据质量，解释机器为什么提示以及何时不应提示。  
**English caption**: The prototype keeps behaviour and data quality visible together, explaining both cues and silence.  
**日本語キャプション**：行動とデータ品質を同時に表示し、提示と沈黙の理由を説明する。

**中文Alt**：仪表板包含设备状态、左右贡献、踏频、提示理由、条件、事件日志、停止和导出。  
**English Alt**: The dashboard includes device status, contribution, cadence, cue reason, condition, event log, stop and export.  
**日本語Alt**：デバイス状態、左右寄与、ケイデンス、提示理由、条件、ログ、停止、出力を含む画面。

### IMG-17

**中文图注**：行为数据只有和工程上下文一起保存时才可解释。  
**English caption**: Behavioural data is interpretable only when engineering context is retained.  
**日本語キャプション**：行動データは工学的文脈と共に保存して初めて解釈できる。

**中文Alt**：一条数据记录被拆成传感、周期、反馈、条件和质量字段。  
**English Alt**: One data record is divided into sensing, cycle, feedback, condition and quality fields.  
**日本語Alt**：一つのデータ記録をセンシング、回転、提示、条件、品質へ分けた図。

### IMG-18

**中文图注**：能力不是自我评分，而是从研究到反思都可以检查的证据链。  
**English caption**: Capability is an inspectable chain from research through reflection—not a self-rating.  
**日本語キャプション**：能力は自己採点ではなく、研究から振り返りまで確認できる証拠の連鎖である。

**中文Alt**：文献、硬件、固件、制作、交互、数据、实验和反思组成的证据链。  
**English Alt**: An evidence chain connects literature, hardware, firmware, fabrication, interaction, data, study and reflection.  
**日本語Alt**：文献、ハードウェア、ファームウェア、制作、インタラクション、データ、実験、振り返りの証拠チェーン。

## 2. 核心按钮

| ID | 中文 | English | 日本語 |
|---|---|---|---|
| BTN-01 | 查看系统闭环 | Explore the System | システムを見る |
| BTN-02 | 打开交互原型 | Open Interactive Prototype | インタラクティブ・プロトタイプを開く |
| BTN-03 | 查看原型与制作 | Explore Prototype & Making | プロトタイプと制作を見る |
| BTN-04 | 查看实验与证据 | Explore Experiment & Evidence | 実験と証拠を見る |
| BTN-05 | 查看材料清单 | View Bill of Materials | 部品表を見る |
| BTN-06 | 查看开源复用 | View Open-source Reuse | OSS再利用を見る |
| BTN-07 | 开始系统导览 | Start System Walkthrough | システムを見る |
| BTN-08 | 连接硬件 | Connect Hardware | 実機に接続 |
| BTN-09 | 重复校准 | Repeat Calibration | 校正をやり直す |
| BTN-10 | 开始此条件 | Run This Condition | この条件を開始 |
| BTN-11 | 保存过去自我轨迹 | Save Past-self Trace | 過去自己の軌跡を保存 |
| BTN-12 | 立即关闭输出 | Stop All Output | すべての出力を停止 |
| BTN-13 | 导出会话数据 | Export Session Data | セッションデータを出力 |

## 3. 状态文字

| ID | 中文 | English | 日本語 |
|---|---|---|---|
| ST-01 | 准备就绪 | Ready | 準備完了 |
| ST-02 | 未连接 | Missing | 未接続 |
| ST-03 | 信号不稳定 | Unstable | 信号が不安定 |
| ST-04 | 本条件不使用 | Not used | この条件では未使用 |
| ST-05 | 正在校准 | Calibrating | 校正中 |
| ST-06 | 正在记录基线 | Recording baseline | ベースライン記録中 |
| ST-07 | 有效踏圈 | Valid revolution | 有効回転 |
| ST-08 | 无效踏圈，不提示 | Invalid revolution—no cue | 無効回転—提示なし |
| ST-09 | 等待持续偏差 | Waiting for persistent deviation | 継続ずれを確認中 |
| ST-10 | 左侧提示 | Left-side cue | 左側提示 |
| ST-11 | 右侧提示 | Right-side cue | 右側提示 |
| ST-12 | 已回到个人范围 | Back within personal tolerance | 個人許容範囲へ復帰 |
| ST-13 | 反馈已关闭 | Guidance off | ガイダンス停止 |
| ST-14 | 过去自我轨迹 | Past-self trace | 過去自己軌跡 |
| ST-15 | 模拟匹配他人轨迹 | Simulated matched-other trace | 模擬matched-other軌跡 |
| ST-16 | 节点掉线，输出已关闭 | Node lost—outputs silenced | ノード切断—出力停止 |
| ST-17 | 示例模拟，不是实验结果 | Illustrative simulation—not a study result | 例示シミュレーション—実験結果ではありません |

## 4. 安全标签

| ID | 中文 | English | 日本語 |
|---|---|---|---|
| SAFE-01 | 仅限固定室内脚踏 | Stationary indoor use only | 固定式屋内利用のみ |
| SAFE-02 | 只读肌电，不进行电刺激 | Read-only EMG; no electrical stimulation | 読み取り専用EMG・電気刺激なし |
| SAFE-03 | 相对压力代理，不是功率 | Relative pressure proxy—not power | 相対圧力の代理指標・パワーではない |
| SAFE-04 | 非医疗设备 | Not a medical device | 医療機器ではありません |
| SAFE-05 | 不适或故障时立即停止 | Stop on discomfort or fault | 不快・故障時は停止 |
| SAFE-06 | 模拟数据必须明确标记 | Label simulated data explicitly | 模擬データを明示する |

## 5. 图中常用标注

| 中文 | English | 日本語 |
|---|---|---|
| 左脚压力 | Left pedal pressure | 左ペダル圧力 |
| 右脚压力 | Right pedal pressure | 右ペダル圧力 |
| 完整踏圈 | Complete revolution | 1回転 |
| 个人基线 | Personal baseline | 個人ベースライン |
| 相对贡献 | Relative contribution | 相対寄与 |
| 受力扩散片 | Force-spreading puck | 荷重拡散板 |
| 防剪切 | Shear protection | せん断保護 |
| 非接触间隙 | Non-contact gap | 非接触間隔 |
| 运动禁区 | Moving exclusion zone | 可動禁止領域 |
| 可选只读肌电 | Optional read-only EMG | 任意の読み取り専用EMG |
| 左右振动提示 | Bilateral haptic cue | 左右触覚提示 |
| 机械指针 | Physical pointer | 物理ポインター |
| 提示原因 | Cue reason | 提示理由 |
| 数据质量 | Data quality | データ品質 |
| 机器退出 | Machine withdrawal | 機械の撤去 |
| 过去自己 | Past self | 過去の自己 |

