# Page Layout and Interaction Notes

用途：给后续网站设计者/建站 Codex 使用。这里只定义信息架构和交互意图，不提供 HTML、CSS 或 JavaScript。

## 1. 总体页面体系

使用三个主页面，不继续拆分：

1. **Project Vision**：为什么做、研究问题是什么；
2. **Prototype & Making**：怎样做、复用了什么；
3. **Experiment & Capabilities**：怎样验证、证明了哪些能力。

独立交互原型不是第四个内容页面，而是从三页都可以打开的“工具型外链/覆盖层”。

### 桌面端全局导航

- 左侧：PedalBalance Echo 项目标识；
- 中间：三页导航；
- 右侧：语言切换 `中文 / EN / 日本語` 与 `Open Prototype`；
- 不显示搜索、账户、下载 App 等无关功能；
- 当前页清晰高亮；
- 页面滚动时可以保留简洁导航，但不要遮挡大标题。

### 移动端全局导航

- 第一行：项目名 + 语言；
- 第二行：三个页面标签，可横向滚动或换行；
- Prototype 使用文字按钮，不使用只有图标的入口；
- 图注和来源不能因为移动端而隐藏。

## 2. 视觉叙事原则

### 文本与图像比例

- 每个主要概念段落后紧跟对应图，不在页面顶部堆满全部效果图；
- 长段落控制在 2–4 个短段，每个段落回答一个问题；
- 技术表格与人体图交替，避免 Page 2 变成连续硬件清单；
- Page 3 的条件矩阵、流程和数据图优先于装饰性照片。

### 状态标签

建议使用以下公开标签：

- `RESEARCH QUESTION`
- `DESIGN DECISION`
- `OPEN-SOURCE ADAPTATION`
- `PROTOTYPE LOGIC`
- `PLANNED STUDY`
- `SELF-TEST, n=1`
- `ILLUSTRATIVE SIMULATION`
- `SAFETY BOUNDARY`
- `LIMITATION`

标签不能把计划中的工作包装成完成结果。

### 颜色角色

- 左侧身体/传感：冷色；
- 机器计算：中性深色；
- 右侧身体反馈：暖色；
- 安全/故障：红色只用于真正风险，不用于装饰；
- C1 与 E2 可以各有一种强调色，但所有图保持一致。

## 3. Page 1 布局

### Section P1-A｜Hero

**使用内容**：P1-HERO-01 至 P1-HERO-04  
**主图**：IMG-01  
**建议高度**：首屏 70–90% 浏览器高度；移动端不强制满屏。

顺序：眉题 → 主标题 → 摘要 → 两个动作 → 关键事实条。

动作：

- `Explore the System`：滚动到 P1-LOOP-01；
- `Open Interactive Prototype`：新入口/覆盖层；
- 不放 `Buy now` 或产品式 CTA。

### Section P1-B｜Problem

**使用内容**：P1-PROBLEM-01、P1-PROBLEM-02  
**主图**：IMG-03

布局：先显示“屏幕反馈→注意转移”的问题，再用完整踏圈图解释为什么不能逐帧比较左右。

可选交互：一个小型滑杆从“instantaneous”切换到“full revolution”。瞬时模式出现自然交替的假警报；完整踏圈模式才显示相对积分。滑杆只解释概念，不生成研究结果。

### Section P1-C｜Core Insight

**使用内容**：P1-INSIGHT-01  
**构图**：左右踝部局部图 + 一行规则。

规则文字：

```text
Lower left contribution → left cue
Lower right contribution → right cue
Back within tolerance → silence
```

### Section P1-D｜System Loop

**使用内容**：P1-LOOP-01  
**主图**：IMG-02

桌面端可以在左侧显示环图，右侧随选择显示 Human、Machine、Return、Learning 四段文字；移动端按顺序展开，不做横向小字轮播。

### Section P1-E｜Scenario

**使用内容**：P1-SCENARIO-01  
**主图**：IMG-03 的扩展版本。

六步以垂直时间线表示。只有当前步骤的说明展开；不需要自动播放。

### Section P1-F｜Research Questions

**使用内容**：P1-RESEARCH-01、P1-RESEARCH-02  
**主图**：IMG-04

C1 与 E2 两张同权重卡片，不能把 E2 隐藏为未来功能。每张卡片包含：一句问题、四个条件概要、主要结果、下一页锚点。

### Section P1-G｜Related Work and Safety Translation

**使用内容**：P1-RELATED-01、P1-SCOPE-01  
**布局**：研究启发三张卡 + 下方完整安全转译段落。

论文图片如使用，应优先重画概念，不直接截图论文图。完整引用可放页面末尾或脚注。

### Section P1-H｜Principles and Contribution

**使用内容**：P1-DESIGN-01、P1-CONTRIBUTION-01、P1-NEXT-01

四个原则做成短栏；能力主张使用文字证据链，不用技能雷达图。结尾进入 Page 2。

## 4. Page 2 布局

### Section P2-A｜Hero and Architecture

**使用内容**：P2-HERO-01、P2-ARCH-01 至 04  
**主图**：IMG-05、IMG-06

先显示整个零件集合，再显示三节点职责。不要一开始展示采购价格。

可选交互：点击三节点图中的一个节点，只高亮其零件和数据路径；其他节点降低对比度但仍可见。

### Section P2-B｜Component Library

**使用内容**：P2-HW-01 至 P2-HW-10

建议分为四组：

1. Compute：XIAO；
2. Sense：FSR、Hall、EMG；
3. Return：DRV2605L、vibration motor、servo；
4. Build：power、pedal exerciser、tools。

每张零件卡公开显示：名称、数量、职责、一个限制、图片。展开后显示规格、来源和采购参考。价格放次要位置并带日期。

卡片图片发布优先使用本人实拍；供应商图片只作为内部选图参考。

### Section P2-C｜Body and Bicycle Mounting

**使用内容**：P2-MOUNT-01 至 04  
**主图**：IMG-07、IMG-08、IMG-09、IMG-10

顺序：踏板剖面 → 全身安装 → 肌肉/EMG边界 → Hall/舵机。每张图旁边必须显示一个“不能声称什么”的短句。

### Section P2-D｜Data and Algorithm

**使用内容**：P2-DATA-01、P2-ALGO-01

把八步数据流做成从左向右或从上向下的流图。公式区域使用等宽字体，但必须有一句普通语言说明：

> Compare the two sides only after one full revolution has been completed.

### Section P2-E｜Open-source Assembly

**使用内容**：P2-REUSE-01 至 06  
**主图**：IMG-11

每个来源必须显示三个字段：`Reuse`、`Adapt`、`Exclude`。许可证放在来源名旁边。没有确认许可证的教程不显示为“open source”；写成 `tutorial reference`。

### Section P2-F｜14-day Build

**使用内容**：P2-BUILD-01 至 04  
**主图**：IMG-12

时间线默认显示六个阶段，选择阶段后显示当天任务、验收门槛和证据。不要使用自动滚动动画。

### Section P2-G｜Gates, Budget, Deliberate Exclusions

**使用内容**：P2-GATE-01、P2-COST-01、P2-DONTBUY-01、P2-NEXT-01

测试门槛优先于预算。预算只作为范围说明；“不购买”用来展示判断，而不是显得缺乏设备。

## 5. Page 3 布局

### Section P3-A｜Hero and Common Question

**使用内容**：P3-HERO-01、P3-FRAME-01  
**主图**：IMG-13

页首明确写 `PLANNED STUDY` 或真实状态，不能只靠脚注说明。

### Section P3-B｜Calibration and Session

**使用内容**：P3-CAL-01、P3-SESSION-01

校准五步可做成逐步展开；每一步显示输入、通过条件、失败动作。不要把校准设计成“一键完成”的假象。

### Section P3-C｜C1

**使用内容**：P3-C1-01、P3-C1-02、P3-RULE-01  
**主图**：IMG-14

四个条件同屏比较；AF 不预先标成最佳。下方放 training 与 no-feedback 的分段示例图，并用明显标签区分模拟数据。

### Section P3-D｜E2

**使用内容**：P3-E2-01 至 03  
**主图**：IMG-15

先解释轨迹怎样保存，再显示四条件。`simulated_matched_other` 不能缩成小字或仅放 tooltip。

### Section P3-E｜Measures, Data and Failure

**使用内容**：P3-METRIC-01、P3-METRIC-02、P3-DATA-01、P3-FAIL-01  
**主图**：IMG-16、IMG-17

主研究指标与工程质量并列显示，避免把丢包和无效圈放在附录。故障表在移动端改为逐项卡片，不强行压缩七列。

### Section P3-F｜Safety, Ethics and Limitations

**使用内容**：P3-SAFETY-01、P3-ETHICS-01、P3-LIMIT-01

安全使用完整段落，不使用只显示警告图标的折叠组件。局限至少显示前五项，其余可以展开。

### Section P3-G｜Capabilities and Evidence

**使用内容**：P3-SKILL-01、P3-EVIDENCE-01  
**主图**：IMG-18

不要使用“80% coding / 70% electronics”雷达图。每个能力必须连接到文件、照片、日志或视频。

### Section P3-H｜Prototype, Demo and Reflection

**使用内容**：P3-PROTOTYPE-01、P3-DEMO-01、P3-REFLECT-01、P3-NEXT-01

Prototype 入口放在本节顶部。90 秒脚本按时间码展示。结尾使用一句反思和下一步，不以购买按钮结束。

## 6. 原型入口

三个页面都可以出现 `Open Interactive Prototype`，但位置不同：

- Page 1：Hero 次级动作；
- Page 2：数据与算法之后；
- Page 3：能力证据之前的主要动作。

入口旁必须写：

> Simulation explains the system logic; it is not a study result.

## 7. 三语切换

- 使用同一个页面路径和稳定 content ID；
- 切换语言时保持当前段落位置；
- 不把中文、英文、日文同时堆叠在页面；
- 产品型号和条件缩写不翻译；
- alt text 随语言切换；
- 日文页面第一次出现缩写时显示日文解释；
- 引用标题保持论文原文，说明文字翻译。

## 8. 建站时的内容删减顺序

如果某一页面过长，按以下顺序删减：

1. 删除重复的采购价格；
2. 将详细教程链接移到来源抽屉；
3. 将 D1–D14 详细文字折叠为阶段；
4. 将数据字段完整表移到可展开区域；
5. 保留研究问题、身体映射、开源复用边界、无辅助结果、安全和局限。

不得优先删掉安全、来源或“planned/self-test/simulation”状态。

## 9. 无障碍与可读性

- 所有图使用 `captions-alt-text-labels.md` 中的对应 alt；
- 颜色不是区分左右、C1/E2 或故障的唯一方式；同时使用文字/形状；
- 图中最小文字在移动端仍可读；
- Prototype 的所有操作可通过键盘完成；
- 动画支持暂停，并尊重 reduced-motion；
- 数据图提供文字摘要；
- 外链标记为新窗口但不强制；
- 引用和来源不只放在 hover 状态。

