# Page 2｜Prototype & Making：原型与制作

[PORTFOLIO NOTE] 本页展示“我怎样把研究问题转成装置”。不要把 BOM 做成电商列表；每个零件先解释它在系统中的职责，再提供采购来源。

---

[CONTENT ID: P2-META-01]

**页面标题**  
Prototype & Making｜从三块开发板到完整身体闭环

**页面摘要**  
PedalBalance Echo 使用三个 XIAO ESP32-C3、两片 FSR、Hall 踏圈传感、双侧触觉和一个机械指针构成最小闭环。制作过程优先复用已有库、教程和开源项目；每一个模块先独立验证，再进入无线集成。

---

[CONTENT ID: P2-HERO-01]

# 把研究问题做成一个可以逐层调试的装置

为了在两周内完成，我没有从空白电路、无线协议或触觉驱动器开始。系统被拆成左脚节点、右脚节点和中央节点，每个节点只有一个明确职责；成熟的传感器、电机驱动库和 ESP-NOW 示例负责底层工作，我把时间放在自行车动作映射、完整踏圈算法、反馈撤除和实验日志上。

**页首短句**  
Build small. Test one signal at a time. Integrate only after every module can fail safely.

[IMAGE IMG-05] 所有主零件在中性背景上分组俯拍：三块 XIAO、两片 FSR、两块 DRV2605L、三个振动电机、Hall、磁铁、舵机、EMG、两块电池和固定脚踏器。每组只标名称与数量。

[CAPTION] 一套低成本、模块化的身体接口：压力和踏圈进入机器，触觉和机械运动返回身体。

[ALT] PedalBalance Echo 的主要电子零件和固定脚踏器按输入、计算、输出和可选验证模块排列。

---

[CONTENT ID: P2-ARCH-01]

## 三节点架构

```text
左脚压力 + 可选EMG → 左脚节点 ─┐
                                ├─ ESP-NOW → 中央节点 → USB → 作品集原型/数据文件
右脚压力             → 右脚节点 ─┘               ├─ Hall：划分完整踏圈
                                                    └─ 舵机：实体左右指针

中央节点 → ESP-NOW → 左/右脚节点 → 对应侧踝部振动
```

这种拆分减少了穿过曲柄的线缆。脚部节点由电池供电，中央节点固定在脚踏器上并通过 USB 与电脑连接。两个脚部节点分别拥有自己的 DRV2605L，因此不会遇到两块同地址 I2C 设备挂在同一总线上的冲突。

[IMAGE IMG-06] 三节点方框图，使用三种颜色区分 sensing、computation 和 feedback。每条箭头写明协议：Analog ADC、ESP-NOW、I2C、USB Serial、PWM。

[CAPTION] 模块边界使压力、无线、踏圈、触觉和网页可以分别测试，也使任何单个故障都能被定位。

[ALT] 左右脚节点通过 ESP-NOW 连接中央节点，中央节点连接 Hall、舵机和电脑，并把触觉指令返回双脚。

[CONTENT ID: P2-ARCH-02]

### 左脚节点

- XIAO ESP32-C3；
- 一片 FSR 与 10 kΩ 分压电路；
- 一片 DRV2605L 与一个 10 mm 振动电机；
- 一块 3.7 V 受保护 LiPo；
- 可插拔 SEN0240 EMG 模块；
- 任务：50–100 Hz 压力采样、25–50 Hz 无线发包、接收触觉指令；
- 安全：失去中央节点指令时自动关闭振动。

[CONTENT ID: P2-ARCH-03]

### 右脚节点

- 与左脚节点相同，但不安装 EMG；
- 使用独立节点 ID、包序号和电池；
- 任务：读取右脚相对压力，返回右侧触觉提示；
- 左右固件共享同一代码基线，只通过配置区分 `LEFT` 与 `RIGHT`。

[CONTENT ID: P2-ARCH-04]

### 中央节点

- XIAO ESP32-C3，通过 USB 数据线连接电脑；
- 非锁存 Hall 传感器与曲柄磁铁；
- 9 g 舵机和纸板/3D 打印平衡表盘；
- 任务：接收双侧数据、统计丢包、切分踏圈、计算指标、控制指针、下发提示并输出日志；
- 舵机使用独立 5 V 电源并与中央节点共地，不能从 GPIO 取电。

---

[CONTENT ID: P2-HW-01]

## 01｜XIAO ESP32-C3：三个节点的共同计算核心

这块 21 × 17.8 mm 的开发板把 ESP32-C3、Wi‑Fi、BLE、USB-C、I2C、PWM、ADC 和锂电管理压缩到适合穿戴原型的尺寸。官方资料列出 4 个 ADC 输入；实际设计优先使用 A0/A1/A2 的 ADC1，避开官方文档提示可能出现错误采样的 A3/ADC2。

**购买数量**：3；可选再买 1 块备件。  
**在项目中的职责**：两个脚部节点采样并通信，一个中央节点计算并记录。  
**复用价值**：同一板型减少驱动、烧录和备用件复杂度。

[IMAGE] 使用官方正面和背面产品图作选图参考；公开发布优先换成本人购买后的实拍，并在旁边放一枚硬币或尺子表示尺寸。

[SOURCE]

- [Seeed Studio XIAO ESP32-C3 官方入门与规格](https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/)
- [澳洲采购参考：Core Electronics](https://core-electronics.com.au/seeed-studio-xiao-esp32c3-tiny-mcu-board-with-wi-fi-and-ble-battery-charge-supported-power-efficiency-and-rich-interface.html)

[CONTENT ID: P2-HW-02]

## 02｜Interlink 402 FSR：记录相对压力变化

FSR 是随受力改变电阻的薄膜传感器。它便宜、薄、容易接 ADC，非常适合原型；但非线性、迟滞、个体差异和安装受力方式都会影响结果。它不是称重传感器，也不能给出医学级踩踏力。

每片 FSR 与 10 kΩ 电阻组成分压电路。左右先用相同重量做零点、重复性和比例校准；算法保留原始 ADC、滤波值和校准值，不把它们直接换算成瓦数。

**购买数量**：2；时间允许可买第 3 片备件。  
**安装重点**：不能让鞋底横向剪切薄膜尾部；不要直接在薄膜引脚处焊接，使用母座或端子。

[SOURCE]

- [Little Bird：Interlink 402 FSR](https://littlebirdelectronics.com.au/products/round-force-sensitive-resistor-fsr-interlink-402)
- [Adafruit FSR 原理与分压教程](https://learn.adafruit.com/force-sensitive-resistor-fsr)

[CONTENT ID: P2-HW-03]

## 03｜DRV2605L：不从零设计触觉电机驱动

DRV2605L 是专门控制 ERM/LRA 触觉电机的 I2C 驱动器。与简单开关电机相比，它提供预设的 click、ramp 和不同强度波形；Adafruit 已提供 Arduino 库、接线和示例。

本项目在左右脚节点各放一块驱动器，把触觉定义为弱、中、强三组明确波形。这样可以避免用 GPIO 直接驱动电机，也减少自行设计晶体管驱动和波形调制的时间。

**购买数量**：2。  
**使用边界**：第一版只选三种差异明显的短波形，不让电机持续长震。

[SOURCE]

- [Adafruit DRV2605L 官方教程](https://learn.adafruit.com/adafruit-drv2605-haptic-controller-breakout/overview)
- [Adafruit DRV2605 Arduino Library](https://github.com/adafruit/Adafruit_DRV2605_Library)
- [澳洲采购参考：Core Electronics](https://core-electronics.com.au/adafruit-drv2605l-haptic-motor-controller.html)

[CONTENT ID: P2-HW-04]

## 04｜10 mm 振动电机：把左右信息交还脚踝

硬币式 ERM 电机体积小，适合固定在踝带外侧。它不放在踏板下方，因为踏板本身的机械振动会削弱左右定位，同时增加 FSR 信号污染。

**购买数量**：3，左右各一、一个备件。  
**身体映射**：左侧贡献不足→左踝短震；右侧贡献不足→右踝短震；恢复→停止。  
**验证**：闭眼十次左右随机定位，至少正确八次。

[SOURCE]

- [Little Bird：10 mm Mini Vibration Motor](https://littlebirdelectronics.com.au/products/mini-vibration-motor-10-2-7mm?collection=dfrobot)

[CONTENT ID: P2-HW-05]

## 05｜Hall 传感器与磁铁：为每一个完整踏圈建立边界

非锁存 Hall 传感器在磁铁经过时产生一次事件。磁铁固定在曲柄或旋转件的安全位置，Hall 固定在车架；二者不接触。中央节点用相邻事件之间的时间计算踏频，并把这段时间定义为一个 `cycle_id`。

**购买数量**：Hall 2 个，其中 1 个备件；小型稀土磁铁一包。  
**机械要求**：磁铁采用机械固定与胶带/扎带双保险；线材和支架完全离开曲柄路径。

[SOURCE]

- [AH1815 非锁存 Hall 传感器](https://core-electronics.com.au/hall-effect-sensor-ah1815-non-latching.html)
- [ESP32 stationary bike Hall/FTMS 示例](https://github.com/jamesjmtaylor/esp32-ftms-server)

[CONTENT ID: P2-HW-06]

## 06｜9 g 舵机：让机器的判断变成看得见的实体动作

中央舵机驱动一根小指针。指针中心表示个人基线，向左或向右偏转表示当前完整踏圈的相对变化。它不是精密仪表，而是一件 tangible display：机器不仅在屏幕里计算，也在物理世界中改变状态。

舵机先安装在纸板表盘上，尺寸确认后再制作 3D 外壳。使用独立 5 V 电源，与中央节点共地；角度要设置软限位，避免机械卡死。

[SOURCE]

- [Jaycar 9 g Micro Servo](https://www.jaycar.com.au/arduino-compatible-9g-micro-servo-motor/p/YM2758)

[CONTENT ID: P2-HW-07]

## 07｜SEN0240：可选的只读表面肌电模块

DFRobot/OYMotion SEN0240 使用干电极和集成放大/滤波电路，以 1.5 V 为参考输出 0–3.0 V 模拟信号；官方工作供电范围为 3.3–5.5 V。它的作用是展示“肌肉活动可以作为身体输入”，并把肌电包络与踏圈时间对齐。

它不参与左右提示的控制，也不用于判断疲劳、伤病、肌肉强弱或动作正确性。运动中的线缆、皮肤接触、串扰和振动伪迹都会影响读数，因此主实验在 EMG 缺失时仍应完整运行。

**购买数量**：1。  
**第一次测试**：先在静止、轻收缩条件下观察信号；只有在绑带和线缆能安全固定时才尝试低速踩踏。

[SOURCE]

- [DFRobot SEN0240 官方文档、规格与电极方向说明](https://wiki.dfrobot.com/sen0240/)
- [澳洲采购参考：Core Electronics](https://core-electronics.com.au/gravity-analog-emg-sensor-by-oymotion.html)

[CONTENT ID: P2-HW-08]

## 08｜LiPo 与电源：让穿戴节点脱离曲柄线缆

左右脚节点各使用一块受保护 3.7 V LiPo。XIAO ESP32-C3 支持锂电供电和充电管理，但接线前必须核对正负极与连接器极性。充电时设备离开身体并放在不可燃表面；鼓包、破损、异常发热时立即停止使用。

中央节点通过 USB 供电，舵机另用 5 V / 2 A 电源。第一周台架阶段可以先使用 USB 移动电源，等固件和功耗稳定后再封装 LiPo。

[SOURCE]

- [Seeed XIAO ESP32-C3 Battery Usage](https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/#battery-usage)
- [400 mAh protected LiPo 采购参考](https://core-electronics.com.au/polymer-lithium-ion-battery-400mah-38456.html)

[CONTENT ID: P2-HW-09]

## 09｜固定脚踏器：把身体实验限制在可控环境

一个带脚带、可调阻力的小型固定脚踏器足以完成原型。项目不需要道路自行车、昂贵训练台或商业功率计。测试从低阻力、低速开始，装置放在防滑地面，参与者保持稳定坐姿。

[SOURCE]

- [Everfit Mini Pedal Exerciser 采购参考](https://www.kmart.com.au/product/everfit-pedal-exerciser-mini-exercise-bike-cross-trainer-under-desk-bike-black-110070790/)

[CONTENT ID: P2-HW-10]

## 10｜工具与耗材：让原型从面包板进入可穿戴状态

必备工具包括烙铁、万用表、吸锡器、剪钳、剥线钳、烙铁架、护目镜和 USB-C 数据线。耗材包括小面包板、10 kΩ/1 kΩ/220 Ω 电阻、100 nF 电容、22–26 AWG 硅胶线、母座/端子、热缩管、魔术贴、EVA 泡棉、受力扩散片、扎带和 M2/M3 螺丝。

制作证据不只拍成品。作品集应保留：第一次面包板、万用表连续性检查、焊接前后、热缩与拉力缓解、错误接线、返工和最终模块的对照照片。

[SOURCE]

- [Jaycar 焊接与万用表入门套装](https://www.jaycar.com.au/25w-soldering-iron-starter-kit-with-dmm/p/TS1652)

---

[CONTENT ID: P2-COST-01]

## 预算不是实时报价，而是范围控制工具

2026-08-13 的规划记录中，三块 XIAO、双侧 FSR/触觉、Hall、舵机、EMG、工具和脚踏器的主商品合计约 AUD 344.65。加入耗材、运费和可选 3D 打印后，完整“从零开始”预算约 AUD 395–515。

这个数字在作品集中只能作为有日期的历史估算。商品价格与库存会变化，不能显示为当前报价。若已有工具和固定自行车，并暂缓 EMG，最小闭环可以显著降低成本。

---

[CONTENT ID: P2-MOUNT-01]

## 踏板安装：保护 FSR，也保护指标含义

FSR 放在踏板软质覆盖层下。传感圆区上方放一枚 20–30 mm 硬质受力扩散片，下面加 2–5 mm EVA，使鞋底压力落到感应区，同时减少尖点加载。薄膜尾部沿踏板边缘引出并做拉力缓解。

第一周使用魔术贴和可拆结构，不用永久胶。只有在反复踩踏后确认位置稳定、信号重复性可接受，才为传感器设计 3D 槽位。

[IMAGE IMG-07] 踏板剖面爆炸图：shoe、soft cover、force-spreading puck、FSR sensing area、EVA layer、pedal body、protected tail、connector。用红色叉号标出“sharp point load”和“shear on tail”。

[CAPTION] FSR 需要受力扩散和防剪切结构；安装方式本身会改变数据，因此必须记录并固定。

[ALT] 踏板剖面显示鞋底、软覆盖层、受力扩散片、FSR、EVA 和踏板本体，并标明受保护的传感器尾部。

[CONTENT ID: P2-MOUNT-02]

## 触觉安装：把“哪一侧”编码在身体位置中

两个振动电机固定在左右踝外侧的软绑带上，避开骨性突出和皮肤不适区域。电机线沿绑带固定，并在进入节点外壳前留出应力缓冲。每次穿戴后重新做左右定位检查。

提示强度不是越大越好。项目优先通过位置、短波形和节奏建立可辨识性；连续震动会造成适应，也会污染可选 EMG。

[CONTENT ID: P2-MOUNT-03]

## 肌肉与只读 EMG：用一个局部信号理解全身动作的限制

自行车踩踏由多个下肢肌群在不同曲柄阶段共同完成。股外侧肌（vastus lateralis）与膝伸展相关，是常见的表面 EMG 观察位置之一；但单点 EMG 不能代表整条腿贡献，更不能从其幅值直接推断踩踏力。

作品集的人体图可以把股四头肌、腘绳肌、臀大肌、腓肠肌和胫骨前肌作为动作背景标出，再用不同颜色强调“本原型只读取一个说明性通道”。传感器方向遵循厂商与 SENIAM 的一般原则，与肌纤维方向一致、固定线缆、减少运动伪迹；实际佩戴应在导师或有经验人员指导下完成。

如果 SEN0240 干电极绑带不能稳定、安全地固定在大腿上，第一版只在前臂做静态信号链演示，并把腿部 EMG 写为计划中的扩展，而不是勉强采集不可解释的数据。

[IMAGE IMG-09] 下肢外侧简化肌肉图，标出 vastus lateralis、gluteus maximus、hamstrings、gastrocnemius、tibialis anterior。一个蓝色区域表示“illustrative read-only sEMG channel”，旁边写“not total leg force”。

[CAPTION] 单通道表面肌电可以展示活动时序，但无法代表整条腿的机械贡献；压力、踏圈和 EMG 必须分开解释。

[ALT] 下肢肌肉示意图突出股外侧肌的只读表面肌电通道，并标明它不能代表整条腿的力量。

[SOURCE]

- [Electromyographic analysis of pedaling: a review](https://pubmed.ncbi.nlm.nih.gov/18093842/)
- [SENIAM sensor placement and fixation](https://www.seniam.org/fixation.htm)
- [SENIAM vastus lateralis recommendation](https://seniam.org/quadricepsfemorisvastuslateralis.html)

[CONTENT ID: P2-MOUNT-04]

## Hall 与机械安装：任何零件都不能进入运动路径

Hall 支架固定在静止车架上，磁铁固定在旋转件上，两者保持非接触间隙。磁铁不能只依赖胶水；必须有第二道机械保险。中央节点、舵机、电源和 USB 线全部位于曲柄之外。

第一版支架用泡棉、扎带和纸板确认尺寸。3D 建模只做三个小件：Hall 支架/磁铁座、中央舵机表盘盒、左右脚节点夹具。没有必要为了两周项目购买 3D 打印机。

[IMAGE IMG-10] 左侧显示 Hall 与磁铁非接触安装，右侧显示舵机指针和 5 V 独立供电。运动禁区用半透明红色弧表示。

---

[CONTENT ID: P2-DATA-01]

## 数据怎样穿过系统

1. 左右 FSR 以 50–100 Hz 采样，保存原始 ADC 与 EMA 滤波值；
2. 脚部节点每 20–40 ms 发送带时间戳、节点 ID 和包序号的数据包；
3. 中央节点记录接收时间和丢包，Hall 事件关闭当前踏圈；
4. 机器计算左右积分、`left_share`、个人基线偏差和有效圈标志；
5. 规则决定是否向左/右节点发送触觉等级；
6. 舵机显示相对趋势；
7. USB Serial 把数据送到电脑，原型界面显示并导出 CSV/JSON；
8. 保存的历史轨迹带来源、日期、条件和版本号，供 E2 重放。

[CONTENT ID: P2-ALGO-01]

## 最小算法

```text
left_area  = 当前完整踏圈内左侧校准压力的时间积分
right_area = 当前完整踏圈内右侧校准压力的时间积分
left_share = left_area / (left_area + right_area)
delta      = left_share - baseline_left_share
```

当左右积分和太低、Hall 超时、节点掉线或包损失过高时，该圈标记为无效，不产生身体提示。原型阈值从 60 秒个人基线的波动出发，例如均值 ± 1.5 个标准差，再通过试跑调整；它不是医学标准。

---

[CONTENT ID: P2-REUSE-01]

## 开源复用 01｜Smart Chair：拿走传感器管线，不复制座椅任务

`qppd/smart-chair` 已经实现 ESP32 + FSR、个人 tare、EMA、阈值、触觉脉冲、串口命令和 CSV 日志，并提供 Fritzing 接线与 Fusion 360 模型。它是本项目最接近的底层参考。

**直接复用**：10 kΩ 分压、tare/EMA、非阻塞计时、触觉测试、CSV logger、MIT 署名。  
**必须改写**：从静态座椅左右差改成按完整踏圈积分；其 100 次采样平均对快速踩踏可能过慢，需要改成更短窗口或 EMA。  
**不复制**：姿势分类、五个 FSR、背部弯曲传感器和座椅健康声称。

[SOURCE] [qppd/smart-chair](https://github.com/qppd/smart-chair) — MIT

[CONTENT ID: P2-REUSE-02]

## 开源复用 02｜ESP-NOW：使用官方多节点通信示例

Espressif 的 Arduino ESP-NOW 文档已经提供 peer、send、receive、callback 和多设备 broadcast 示例。本项目在此基础上定义统一包结构，不自己实现无线协议栈。

**直接复用**：初始化、peer 注册、发送/接收回调。  
**新增**：`node_id`、`packet_seq`、采样时间、压力值、电池/故障标志和双向触觉命令。  
**验证**：拔掉任一脚部节点，500 ms 内中央节点停止双侧触觉并标红掉线。

[SOURCE] [Espressif Arduino ESP-NOW 官方文档](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/espnow.html)

[CONTENT ID: P2-REUSE-03]

## 开源复用 03｜ESP32 FTMS Server：拿走 Hall 踏频与支架思路

`esp32-ftms-server` 是为固定自行车制作的 ESP32 Hall 转速计，并包含 `tachMount.stl`。本项目只复用 Hall 事件、去抖和安装思路，不在两周内实现完整 Bluetooth FTMS。

[SOURCE] [jamesjmtaylor/esp32-ftms-server](https://github.com/jamesjmtaylor/esp32-ftms-server) — MIT

[CONTENT ID: P2-REUSE-04]

## 开源复用 04｜Adafruit DRV2605 Library：直接使用触觉波形库

安装官方 Arduino 库，先运行例程确认电机和驱动器，再选择三种短波形作为弱、中、强提示。再发布代码时保留 MIT 许可证和原作者声明。

[SOURCE] [Adafruit_DRV2605_Library](https://github.com/adafruit/Adafruit_DRV2605_Library) — MIT

[CONTENT ID: P2-REUSE-05]

## 开源复用 05｜Insole Pressure Sensor：只作为多通道升级路线

Brillnova 的项目包含 ESP32、MUX、每脚最多 16 通道压力、50 ms 帧、时间戳、Python 可视化和制作视频。MVP 不需要把复杂度提高到智能鞋垫；它只用于展示未来怎样扩展空间分辨率和热图。

该仓库使用 CC BY-NC 4.0，允许署名后的非商业使用和修改，禁止商业使用。如果作品集网站用于商业服务或项目进入商业化，需要重新评估是否可以复用代码。

[SOURCE] [Brillnova/Insole-Pressure-Sensor](https://github.com/Brillnova/Insole-Pressure-Sensor) — CC BY-NC 4.0

[CONTENT ID: P2-REUSE-06]

## 开源复用 06｜DFRobot EMG 示例：只按该型号的官方电路学习

SEN0240 官方 Wiki 提供校准、波形打印、动作计数和干电极方向说明。项目只加入统一时间戳、包序号和 CSV 字段。

不要把其他 EMG 教程中可能需要正负电源轨的电路抄到 SEN0240。产品相似不代表供电和输出完全相同。

[SOURCE]

- [SEN0240 Wiki](https://wiki.dfrobot.com/sen0240/)
- [DFRobot Clever Rabbit Hat：EMG→舵机演示](https://www.dfrobot.com/blog-1129.html)

[IMAGE IMG-11] 六块开源拼图，每块写 “Reuse / Adapt / Exclude”。用箭头说明各项目进入 PedalBalance Echo 的具体模块，而不是只排 GitHub Logo。

[CAPTION] 快速完成不等于复制成品；关键是明确继承哪些模块、改写哪些假设、放弃哪些无关功能。

---

[CONTENT ID: P2-BUILD-01]

## 14 天制作计划：每一天都留下可以展示的证据

制作顺序采用“双轨”：网页模拟器始终能独立展示研究逻辑；硬件按单模块逐步替换模拟数据。这样物流或某个传感器失败时，作品集仍有完整叙事。

[IMAGE IMG-12] 14 天横向时间线，分为 Sense、Connect、Compute、Return、Study、Document 六条泳道。每个节点写当天的可见成果，而不只写任务。

[CONTENT ID: P2-BUILD-02]

### D1–D4｜先让信号可靠，再谈完整系统

**D1：采购与模拟。** 建立仓库、BOM、风险表和无硬件模拟器。  
**D2：单片 FSR。** 完成分压、原始曲线、EMA 和同重量十次重复。  
**D3：左右节点。** 分别校准，双手交替按压模拟踩踏，加入节点 ID。  
**D4：ESP-NOW。** 两个发送节点到中央接收，加入包序号、丢包率和失联保护。

**可展示证据**：面包板照片、曲线、校准表、通信日志、拔电故障视频。

[CONTENT ID: P2-BUILD-03]

### D5–D9｜把信号变成踏圈、反馈和界面

**D5：Hall。** 手持磁铁测试，再低速安装到固定脚踏器，完成去抖和 RPM。  
**D6：周期算法。** 用预录数据验证对称、偏左、偏右、空转和掉线。  
**D7：触觉。** 运行官方例程，定义三档波形，完成左右定位测试。  
**D8：舵机。** 纸板表盘、独立电源、软限位和基线中心。  
**D9：电脑端。** 统一模拟/真实数据，显示状态、曲线、条件和导出。

**可展示证据**：Hall 安装、算法测试结果、触觉模式表、实体指针视频、真实数据仪表盘。

[CONTENT ID: P2-BUILD-04]

### D10–D14｜加入肌电、研究条件和作品集证据

**D10：只读 EMG。** 静态轻收缩、包络、时间对齐和振动伪迹标记。  
**D11：3D 建模。** 实测后制作 Hall 支架、舵机盒和镜像脚节点夹具。  
**D12：C1 自测。** 基线、视觉、连续、自适应和无反馈后测。  
**D13：E2 重放。** 保存 past-self，运行 PS-H、模拟 MO-H、PS-V、NF，并改变阻力。  
**D14：演示与备份。** 90 秒视频、README、BOM、接线、CAD、数据字典、许可证和失败日志。

**可展示证据**：EMG 曲线、STL/STEP、条件日志、历史轨迹、迁移数据和完整演示包。

---

[CONTENT ID: P2-GATE-01]

## 五个不能跳过的调试门槛

1. 单个传感器能稳定工作，才接入无线；
2. 左右用同一重量完成十次重复，才安装踏板；
3. Hall 能稳定产生一圈一个事件，才计算相对贡献；
4. 闭眼左右定位达到 8/10，才让触觉进入实验；
5. 任一节点断开后 500 ms 内停止输出，才允许身体佩戴。

如果某个门槛失败，系统回退到上一个可以证明的层级，不通过提高阈值或隐藏日志来“让演示看起来成功”。

---

[CONTENT ID: P2-DONTBUY-01]

## 为了两周完成，我主动不购买什么

- 不买 DIY EMS/TENS 刺激器和刺激电极；
- 不买商业功率计踏板；
- 不买 3D 打印机；
- 不下单定制 PCB；
- 不把 MVP 扩展为 16 通道智能鞋垫；
- 不买第二套 EMG、示波器或云服务器；
- 不把手机 App、账户系统和云同步放进第一版。

范围控制也是工程能力。项目需要完成的是一个可验证的人—机器—人闭环，而不是所有可能功能的集合。

---

[CONTENT ID: P2-NEXT-01]

## 下一页：怎样证明它不只是一个会震动的装置？

下一页把硬件转成实验：校准、C1 反馈撤除、E2 过去自我重放、数据指标、安全边界和导师能够检查的能力证据。

**链接文字**  
查看实验设计与能力证据 →

[INTERACTION] 建站时可以把 BOM 做成十张可展开卡片。默认只显示职责、数量和状态；点击后显示技术边界、来源和“我复用了什么”。不要让价格成为页面最醒目的信息。

